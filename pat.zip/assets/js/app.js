// ===============================
// Prime Autonomous Trading
// app.js
// ===============================

const app = document.getElementById("app");

let aiStatusInterval = null;


// ===============================
// PAGE LOADER
// ===============================
function openPage(page, element) {

    document.querySelectorAll(".nav").forEach(nav => {
        nav.classList.remove("active");
    });

    if (element) {
        element.classList.add("active");
    }


    fetch("./modules/" + page + ".html")
        .then(response => {

            if (!response.ok) {
                throw new Error("Module not found: " + page);
            }

            return response.text();

        })

        .then(data => {

            document.getElementById("app").innerHTML = data;

            initializePage(page);

        })

        .catch(error => {

            console.error(error);

            document.getElementById("app").innerHTML = `
                <h2>Page not found</h2>
                <p>${error.message}</p>
            `;

        });

}



// ===============================
// PAGE INITIALIZER
// ===============================
function initializePage(page) {


    if (aiStatusInterval) {

        clearInterval(aiStatusInterval);

        aiStatusInterval = null;

    }



    document.querySelectorAll(".card").forEach(card => {


        card.addEventListener("touchstart", () => {

            card.style.transform = "scale(.98)";

        });



        card.addEventListener("touchend", () => {

            card.style.transform = "scale(1)";

        });


    });



    if (page === "home") {

        startPortfolioCounter();

    }



    if (page === "ai") {

        startAIAnimation();

    }


}



// ===============================
// TOAST NOTIFICATION
// ===============================
function showToast(message, type = "success") {


    const oldToast = document.querySelector(".toast");

    if (oldToast) {

        oldToast.remove();

    }



    const toast = document.createElement("div");


    toast.className = "toast " + type;


    toast.innerHTML = message;


    document.body.appendChild(toast);



    setTimeout(() => {

        toast.classList.add("show");

    }, 100);



    setTimeout(() => {


        toast.classList.remove("show");


        setTimeout(() => {

            toast.remove();

        }, 300);


    }, 3000);


}



// ===============================
// PAT INVESTMENT CALCULATOR
// ===============================
function calculatePAT() {


    const investment =
        Number(document.getElementById("investment").value);



    if (!investment || investment < 500) {


        showToast(
            "Minimum investment is ₱500",
            "error"
        );


        return;

    }



    const dailyIncome =
        investment * 0.06;



    const totalReturn =
        dailyIncome * 25;



    document.getElementById("daily").innerText =

        "₱" + dailyIncome.toLocaleString();



    document.getElementById("total").innerText =

        "₱" + totalReturn.toLocaleString();




    const aiButton =
        document.getElementById("startAI");



    if (aiButton) {

        aiButton.style.display = "block";

    }



    showToast(
        "Investment calculation completed",
        "success"
    );


}




// ===============================
// START AI INVESTMENT
// ===============================
function startAIInvestment() {


    showToast(
        "AI Investment Started Successfully!",
        "success"
    );


}



// ===============================
// AI STATUS ANIMATION
// ===============================
function startAIAnimation() {


    const status =
        document.querySelector(".ai-status");



    if (!status) return;



    aiStatusInterval = setInterval(() => {


        status.style.opacity = "0.4";



        setTimeout(() => {

            status.style.opacity = "1";

        }, 500);



    }, 2500);


}



// ===============================
// PORTFOLIO COUNTER
// ===============================
function startPortfolioCounter() {


    const display =
        document.getElementById("portfolioAmount");



    if (!display) return;



    let value = 0;


    const target = 50000;



    const timer = setInterval(() => {


        value += 3500;



        if (value >= target) {

            value = target;

            clearInterval(timer);

        }



        display.textContent =

            "₱" + value.toLocaleString();



    }, 20);


}



// ===============================
// OPTIONAL HELPERS
// ===============================
function showLoading() {


    app.innerHTML = `

        <div style="padding:30px;text-align:center">

            Loading...

        </div>

    `;


}



function showError(message) {


    app.innerHTML = `

        <div style="padding:30px;text-align:center;color:red">

            ${message}

        </div>

    `;


}



// ===============================
// START APP
// ===============================
window.onload = () => {


    const activeNav =
        document.querySelector(".nav.active");



    openPage(
        "home",
        activeNav
    );


};
