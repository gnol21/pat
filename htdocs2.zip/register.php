<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$fullName = trim((string)($data['full_name'] ?? $data['fullname'] ?? ''));
$phone = trim((string)($data['phone'] ?? ''));
$password = (string)($data['password'] ?? '');
$sponsorCode = trim((string)($data['sponsor'] ?? ''));

if ($fullName === '' || $phone === '' || $password === '') {
    sendJsonResponse(false, 'Complete required fields.');
}

if (strlen($password) < 6) {
    sendJsonResponse(false, 'Password must be at least 6 characters.');
}

$sponsorId = null;

if ($sponsorCode === '') {
    $sponsorCode = 'ADMIN';
}

$stmt = $pdo->prepare('SELECT id FROM users WHERE referral_code = :code LIMIT 1');
$stmt->execute([':code' => $sponsorCode]);
$sponsor = $stmt->fetch();

if (!$sponsor) {
    $adminStmt = $pdo->prepare(
        'INSERT INTO users (sponsor_id, full_name, phone, password, referral_code, status) VALUES (NULL, :full_name, :phone, :password, :referral_code, :status)'
    );
    $adminStmt->execute([
        ':full_name' => 'Admin',
        ':phone' => '0000000000',
        ':password' => password_hash('admin123', PASSWORD_DEFAULT),
        ':referral_code' => 'ADMIN',
        ':status' => 'active',
    ]);

    $sponsorId = (int)$pdo->lastInsertId();
} else {
    $sponsorId = (int)$sponsor['id'];
}

$base = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $fullName));
$phoneDigits = preg_replace('/\D/', '', $phone);
$prefix = substr($base, 0, 3);
$suffix = substr($phoneDigits, -4);

$referralCode = $prefix . $suffix . strval(rand(100, 999));
$referralCode = strtoupper($referralCode);

for ($i = 0; $i < 10; $i++) {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE referral_code = :code LIMIT 1');
    $stmt->execute([':code' => $referralCode]);

    if (!$stmt->fetch()) {
        break;
    }

    $referralCode = $prefix . $suffix . strval(rand(100, 999));
    $referralCode = strtoupper($referralCode);
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'INSERT INTO users (sponsor_id, full_name, phone, password, referral_code, status) VALUES (:sponsor_id, :full_name, :phone, :password, :referral_code, :status)'
    );

    $stmt->execute([
        ':sponsor_id' => $sponsorId,
        ':full_name' => $fullName,
        ':phone' => $phone,
        ':password' => $hashedPassword,
        ':referral_code' => $referralCode,
        ':status' => 'active',
    ]);

    $userId = (int)$pdo->lastInsertId();

    $walletStmt = $pdo->prepare('INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (:user_id, 0, 0, 0, 0, 0)');
    $walletStmt->execute([':user_id' => $userId]);

    $pdo->commit();

    sendJsonResponse(true, 'Account created successfully.', [
        'user' => [
            'id' => $userId,
            'full_name' => $fullName,
            'phone' => $phone,
            'referral_code' => $referralCode,
        ],
    ]);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if (str_contains($e->getMessage(), 'Duplicate entry')) {
        sendJsonResponse(false, 'A user with this full name already exists.');
    }

    sendJsonResponse(false, 'Unable to create account right now.');
}
?>
