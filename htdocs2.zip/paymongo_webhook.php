<?php
header('Content-Type: application/json');
require_once 'server.php';

$payload = file_get_contents('php://input');
if ($payload === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Empty payload']);
    exit;
}

// Verify webhook signature if a webhook secret is configured
$webhookSecret = getPaymongoWebhookSecret();
$signatureHeader = null;
$headers = [];
if (function_exists('getallheaders')) {
    $headers = getallheaders();
} else {
    foreach ($_SERVER as $k => $v) {
        if (strpos($k, 'HTTP_') === 0) {
            $name = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($k, 5)))));
            $headers[$name] = $v;
        }
    }
}

// Common header names PayMongo may use
foreach (['Paymongo-Signature', 'Paymongo-Signature-256', 'Paymongo-Signature256', 'Paymongo-Signature-64', 'Paymongo-Signature64', 'Signature', 'X-Signature', 'Paymongo-Signature-Header'] as $hname) {
    if (isset($headers[$hname])) { $signatureHeader = $headers[$hname]; break; }
    // case-insensitive search
    foreach ($headers as $hk => $hv) {
        if (strtolower($hk) === strtolower($hname)) { $signatureHeader = $hv; break 2; }
    }
}

$webhookSecretLoaded = $webhookSecret !== '';
if ($webhookSecretLoaded) {
    if (empty($signatureHeader)) {
        logPaymongoWebhookError('Missing webhook signature header', ['available_headers' => array_keys($headers), 'webhook_secret_loaded' => true]);
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Missing signature header']);
        exit;
    }
} else {
    logPaymongoWebhookError('Webhook secret not configured', ['available_headers' => array_keys($headers), 'webhook_secret_loaded' => false]);
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Webhook secret not configured']);
    exit;
}

    // Parse common structured signature headers (e.g. "t=...,v1=..." or "t=...,te=...")
    $sig = '';
    $timestamp = '';
    $parts = preg_split('/[;,\s]+/', $signatureHeader);
    foreach ($parts as $part) {
        if (strpos($part, '=') !== false) {
            [$k, $v] = explode('=', $part, 2);
            $k = strtolower(trim($k));
            $v = trim($v);
            if ($k === 'v1' || $k === 'te' || $k === 'sig' || $k === 'signature') {
                $sig = $v;
            } elseif ($k === 't' || $k === 'ts' || $k === 'timestamp') {
                $timestamp = $v;
            }
        } elseif (trim($part) !== '') {
            // fallback: raw token in header
            $sig = trim($part);
        }
    }

    // If header had an equals sign with a single pair like "sha256=...", extract after '='
    if ($sig === '' && strpos($signatureHeader, '=') !== false) {
        [$prefix, $sigpart] = explode('=', $signatureHeader, 2);
        $sig = trim($sigpart);
    }

    $candidatePayloads = [$payload];
    if ($timestamp !== '') {
        $candidatePayloads[] = $timestamp . '.' . $payload;
        $candidatePayloads[] = $timestamp . '|' . $payload;
        $candidatePayloads[] = $timestamp . $payload;
        $candidatePayloads[] = $payload . $timestamp;
    }

    $sigClean = preg_replace('/^sha256=/i', '', $sig);
    $sigClean = trim($sigClean);
    $verified = false;
    $computedMatches = [];

    foreach ($candidatePayloads as $candidate) {
        $computedHex = hash_hmac('sha256', $candidate, $webhookSecret);
        $computedB64 = base64_encode(hex2bin($computedHex));

        if ($sigClean !== '' && (hash_equals($computedHex, $sigClean) || hash_equals($computedB64, $sigClean))) {
            $verified = true;
            break;
        }

        // allow uppercase hex in the header
        if ($sigClean !== '' && hash_equals(strtolower($computedHex), strtolower($sigClean))) {
            $verified = true;
            break;
        }

        $computedMatches[] = [
            'candidate' => $candidate,
            'computed_hex' => $computedHex,
            'computed_b64' => $computedB64,
        ];
    }

    if (!$verified) {
        $logContext = [
            'header' => $signatureHeader,
            'parsed_sig' => $sig,
            'timestamp' => $timestamp,
            'webhook_secret_loaded' => $webhookSecretLoaded,
            'webhook_secret_length' => strlen($webhookSecret),
            'candidates' => array_map(function ($item) {
                return [
                    'computed_hex' => $item['computed_hex'],
                    'computed_b64' => $item['computed_b64'],
                ];
            }, $computedMatches),
        ];
        logPaymongoWebhookError('Invalid webhook signature', $logContext);
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid signature']);
        exit;
    }

$data = json_decode($payload, true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid payload']);
    exit;
}

function logPaymongoWebhook(array $payload): void
{
    $logPath = __DIR__ . '/paymongo_webhook.log';
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
    file_put_contents($logPath, $entry, FILE_APPEND | LOCK_EX);
}

function logPaymongoWebhookError(string $message, array $context = []): void
{
    logPaymongoWebhook(['error' => $message, 'context' => $context]);
}

$eventType = '';
$eventResource = [];
$resourceType = '';
$resourceId = '';
$attributes = [];

if (isset($data['attributes']['data']) && is_array($data['attributes']['data'])) {
    $eventType = $data['attributes']['type'] ?? $data['type'] ?? '';
    $eventResource = $data['attributes']['data'];
} elseif (isset($data['data']) && is_array($data['data'])) {
    $inner = $data['data'];

    if (isset($inner['attributes']['data']) && is_array($inner['attributes']['data'])) {
        $eventType = $inner['attributes']['type'] ?? $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['attributes']['data'];
    } elseif (isset($inner['attributes']) && is_array($inner['attributes'])) {
        $eventType = $inner['attributes']['type'] ?? $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['attributes']['data'] ?? $inner;
    } elseif (isset($inner['data']) && is_array($inner['data'])) {
        $eventType = $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['data'];
    } else {
        $eventType = $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner;
    }
} else {
    $eventType = $data['type'] ?? '';
    $eventResource = $data['data'] ?? $data;
}

if (is_array($eventResource) && isset($eventResource['data']) && is_array($eventResource['data']) && !isset($eventResource['id']) && !isset($eventResource['type'])) {
    $eventResource = $eventResource['data'];
}

$resourceType = $eventResource['type'] ?? $eventType;
$resourceId = $eventResource['id'] ?? $eventResource['payment_intent_id'] ?? '';
$attributes = $eventResource['attributes'] ?? $eventResource;
$resourceStatus = isset($attributes['status']) ? strtolower((string)$attributes['status']) : '';

$metadata = [];
foreach([
    $eventResource['metadata'] ?? [],
    $attributes['metadata'] ?? [],
    $attributes['payment_intent']['metadata'] ?? [],
    $attributes['payment']['metadata'] ?? [],
] as $metadataSource) {
    if (is_array($metadataSource)) {
        $metadata = array_merge($metadata, $metadataSource);
    }
}

$transactionId = '';
if (!empty($attributes['payment_intent_id'])) {
    $transactionId = $attributes['payment_intent_id'];
} elseif (!empty($attributes['payment_intent']['id'])) {
    $transactionId = $attributes['payment_intent']['id'];
} elseif (!empty($attributes['payment']['id'])) {
    $transactionId = $attributes['payment']['id'];
} elseif (!empty($resourceId)) {
    $transactionId = $resourceId;
} elseif (!empty($attributes['id'])) {
    $transactionId = $attributes['id'];
}

$userId = isset($metadata['user_id']) ? (int)$metadata['user_id'] : 0;
$source = strtolower((string)($metadata['source'] ?? ''));

$amount = null;
if (isset($attributes['amount'])) {
    $amount = (float)$attributes['amount'] / 100;
} elseif (isset($attributes['amount_total'])) {
    $amount = (float)$attributes['amount_total'] / 100;
} elseif (isset($attributes['payment_intent']['amount'])) {
    $amount = (float)$attributes['payment_intent']['amount'] / 100;
} elseif (isset($attributes['payment']['amount'])) {
    $amount = (float)$attributes['payment']['amount'] / 100;
}

logPaymongoWebhook([
    'event_type' => $eventType,
    'resource_type' => $resourceType,
    'resource_id' => $resourceId,
    'resource_status' => $resourceStatus,
    'transaction_id' => $transactionId,
    'user_id' => $userId,
    'source' => $source,
    'amount' => $amount,
    'metadata' => $metadata,
    'debug' => [
        'resource_keys' => array_keys($eventResource),
        'attributes_keys' => array_keys($attributes),
    ],
]);

$acceptedEventTypes = [
    'checkout.session.completed',
    'checkout.session.payment.paid',
    'checkout_session.completed',
    'checkout_session.payment.paid',
    'checkout_session',
    'checkout.session',
    // Accept PayMongo payment events as well
    'payment.paid',
    'payment.completed',
    'payment',
];

$accepted = in_array($eventType, $acceptedEventTypes, true)
    || str_starts_with($eventType, 'checkout.session.')
    || str_starts_with($eventType, 'checkout_session.')
    || str_starts_with($eventType, 'payment.')
    || str_starts_with($eventType, 'payment_');

if (!$accepted) {
    echo json_encode(['success' => true, 'message' => 'Webhook received, event ignored']);
    exit;
}

if ($transactionId === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing payment identifier']);
    exit;
}

if ($userId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing user_id in PayMongo metadata']);
    exit;
}

if ($amount === null || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing amount in PayMongo payload']);
    exit;
}

try {
    $pdo = getDatabaseConnection();
    $pdo->beginTransaction();

    $depositStmt = $pdo->prepare('SELECT id, status FROM deposits WHERE transaction_id = ? LIMIT 1');
    $depositStmt->execute([$transactionId]);
    $existingDeposit = $depositStmt->fetch();

    if ($existingDeposit && strtolower($existingDeposit['status']) === 'approved') {
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Webhook already processed', 'transaction_id' => $transactionId]);
        exit;
    }

    if ($existingDeposit) {
        $depositId = (int)$existingDeposit['id'];
        $updateDeposit = $pdo->prepare(
            'UPDATE deposits SET amount = ?, payment_method = ?, status = ? WHERE id = ?'
        );
        $updateDeposit->execute([$amount, 'paymongo', 'approved', $depositId]);
    } else {
        $insertDeposit = $pdo->prepare(
            'INSERT INTO deposits (user_id, amount, payment_method, transaction_id, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())'
        );
        $insertDeposit->execute([$userId, $amount, 'paymongo', $transactionId, 'approved']);
        $depositId = (int)$pdo->lastInsertId();
    }

    $walletStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1');
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();

    $isTradeActivation = ($source === 'pat_trade_now');

    if ($wallet) {
        if ($isTradeActivation) {
            // Trade activation funds should fund an investment directly and stay out of withdrawable balance.
            $depositBal = (float)$wallet['deposit_balance'];
            $profitBal = (float)$wallet['profit_balance'];
            $referralBal = (float)$wallet['referral_balance'];
            $leadershipBal = (float)$wallet['leadership_balance'];
            $newTotalBalance = $depositBal + $profitBal + $referralBal + $leadershipBal;

            $walletUpdate = $pdo->prepare(
                'UPDATE wallets SET total_balance = ? WHERE id = ?'
            );
            $walletUpdate->execute([$newTotalBalance, $wallet['id']]);
        } else {
            // Non-trade deposits increase the withdrawable deposit balance.
            $depositBal = (float)$wallet['deposit_balance'];
            $profitBal = (float)$wallet['profit_balance'];
            $referralBal = (float)$wallet['referral_balance'];
            $leadershipBal = (float)$wallet['leadership_balance'];

            $newDepositBalance = $depositBal + $amount;
            $newTotalBalance = $newDepositBalance + $profitBal + $referralBal + $leadershipBal;

            $walletUpdate = $pdo->prepare(
                'UPDATE wallets SET deposit_balance = ?, total_balance = ? WHERE id = ?'
            );
            $walletUpdate->execute([$newDepositBalance, $newTotalBalance, $wallet['id']]);
        }
    } else {
        if ($isTradeActivation) {
            // Create wallet with zero deposit balance for trade activation; the amount becomes an investment instead.
            $depositBal = 0.0;
            $profitBal = 0.0;
            $referralBal = 0.0;
            $leadershipBal = 0.0;
            $totalBal = $depositBal + $profitBal + $referralBal + $leadershipBal;

            $walletInsert = $pdo->prepare(
                'INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, ?, 0, 0, 0, ?)'
            );
            $walletInsert->execute([$userId, $depositBal, $totalBal]);
        } else {
            // Create wallet with deposit amount and zero for other income types.
            $depositBal = $amount;
            $profitBal = 0.0;
            $referralBal = 0.0;
            $leadershipBal = 0.0;
            $totalBal = $depositBal + $profitBal + $referralBal + $leadershipBal;

            $walletInsert = $pdo->prepare(
                'INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, ?, 0, 0, 0, ?)'
            );
            $walletInsert->execute([$userId, $depositBal, $totalBal]);
        }
    }

    $investmentCreated = false;
    if ($source === 'pat_trade_now') {
        $planStmt = $pdo->prepare('SELECT id, daily_profit_percent, duration_days FROM investment_plans WHERE status = ? ORDER BY id ASC LIMIT 1');
        $planStmt->execute(['active']);
        $plan = $planStmt->fetch();

        if ($plan) {
            $planId = (int)$plan['id'];
            $dailyProfitPercent = (float)$plan['daily_profit_percent'];
            $durationDays = (int)$plan['duration_days'];

            $dailyProfit = round($amount * ($dailyProfitPercent / 100), 2);
            $totalProfit = round($dailyProfit * $durationDays, 2);
            $startDate = date('Y-m-d');
            $endDate = date('Y-m-d', strtotime("+$durationDays days"));

            $existingInvestmentStmt = $pdo->prepare(
                'SELECT id FROM investments WHERE user_id = ? AND amount = ? AND start_date = ? AND status = ? LIMIT 1'
            );
            $existingInvestmentStmt->execute([$userId, $amount, $startDate, 'running']);
            $investmentExists = $existingInvestmentStmt->fetch();

            if (!$investmentExists) {
                $investmentInsert = $pdo->prepare(
                    'INSERT INTO investments (user_id, plan_id, amount, daily_profit, total_profit, start_date, end_date, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())'
                );
                $investmentInsert->execute([
                    $userId,
                    $planId,
                    $amount,
                    $dailyProfit,
                    $totalProfit,
                    $startDate,
                    $endDate,
                    'running'
                ]);
                $investmentCreated = true;

                $walletBalanceStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance FROM wallets WHERE user_id = ? LIMIT 1');
                $walletBalanceStmt->execute([$userId]);
                $walletBalance = $walletBalanceStmt->fetch();

                if ($walletBalance) {
                    $availableBalanceForPortfolio = (float)$walletBalance['deposit_balance'] + (float)$walletBalance['profit_balance'] + (float)$walletBalance['referral_balance'] + (float)$walletBalance['leadership_balance'];
                    $investmentsTotalStmt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total_invested FROM investments WHERE user_id = ?');
                    $investmentsTotalStmt->execute([$userId]);
                    $investmentsTotalRow = $investmentsTotalStmt->fetch();
                    $investedBalanceForPortfolio = $investmentsTotalRow ? (float)$investmentsTotalRow['total_invested'] : 0.0;
                    $portfolioTotal = $availableBalanceForPortfolio + $investedBalanceForPortfolio;

                    $walletUpdateTotal = $pdo->prepare('UPDATE wallets SET total_balance = ? WHERE id = ?');
                    $walletUpdateTotal->execute([$portfolioTotal, $walletBalance['id']]);
                }
            }
        }
        $statusUpdate = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $statusUpdate->execute(['active', $userId]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'PayMongo payment recorded',
        'transaction_id' => $transactionId,
        'deposit_id' => $depositId,
        'investment_created' => $investmentCreated,
    ]);
    exit;
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    logPaymongoWebhookError('Webhook persistence failed', [
        'exception' => $e->getMessage(),
        'event_type' => $eventType,
        'transaction_id' => $transactionId,
        'user_id' => $userId,
        'source' => $source,
    ]);

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to persist webhook event']);
    exit;
}
?>
