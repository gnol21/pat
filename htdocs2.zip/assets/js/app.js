// ===============================
// Prime Autonomous Trading
// app.js
// ===============================

const app = document.getElementById("app");
const STORAGE_KEY = "pat_user";
let aiStatusInterval = null;
let tradeSettings = {
	yieldPercent: 6,
	durationDays: 25
};

function getCurrentUser() {
	try {
		return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
	} catch (error) {
		return null;
	}
}

function formatCurrency(value) {
	return "₱" + Number(value || 0).toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
}

function formatPercent(value) {
	return Number(value || 0).toFixed(2) + "%";
}

function requestJson(url, payload = null, method = "POST") {
	const options = {
		method,
		headers: {
			"Content-Type": "application/json"
		}
	};

	if (payload !== null) {
		options.body = JSON.stringify(payload);
	}

	return fetch(url, options).then(response => response.json());
}


// ===============================
// PAGE LOADER
// ===============================

function openPage(page, element) {

	const bottomNav = document.getElementById("bottomNav");

	if (page === "login" || page === "register") {

		if (bottomNav) bottomNav.style.display = "none";

	} else {

		if (bottomNav) bottomNav.style.display = "flex";

		document.querySelectorAll(".nav").forEach(nav => {
			nav.classList.remove("active");
		});

		const matchingNav = document.querySelector(`.nav[data-page="${page}"]`);
		if (matchingNav) {
			matchingNav.classList.add("active");
		} else if (element) {
			element.classList.add("active");
		}

	}

	fetch("./modules/" + page + ".html")
		.then(response => {

			if (!response.ok) throw new Error("Module not found");

			return response.text();

		})
		.then(data => {

			app.innerHTML = data;
			initializePage(page);

		})
		.catch(error => {

			console.error(error);

			app.innerHTML = "<h2>Page not found</h2>";

		});

}


// ===============================
// PAGE INITIALIZER
// ===============================

function initializePage(page) {

	if (aiStatusInterval) {

		clearInterval(aiStatusInterval);
		aiStatusInterval = null;

	}


	document.querySelectorAll(".card").forEach(card => {

		card.addEventListener("touchstart", () => {

			card.style.transform = "scale(.98)";

		});

		card.addEventListener("touchend", () => {

			card.style.transform = "scale(1)";

		});

	});


	if (page === "login") loadRememberedUser();

	if (page === "register") populateSponsorFromQuery();

	if (page === "home") {
		loadDashboardData();
	}

	if (page === "profile") {
		loadDashboardData(true);
	}

	if (page === "wallet") {
		loadWalletData();
	}

	if (page === "trade") {
		loadTradeData();
	}

	if (page === "ai") {
		startAIAnimation();
		loadAIData();
	}

}


// ===============================
// LOGIN
// ===============================

function login() {

	const username = document.getElementById("username").value.trim();
	const password = document.getElementById("password").value;


	if (!username || !password) {

		showToast("Enter username and password", "error");
		return;

	}


	requestJson("login.php", {
		username: username,
		password: password
	})
		.then(data => {


			if (data.success) {

				localStorage.setItem(
					"pat_user",
					JSON.stringify(data.user)
				);


				showToast("Login successful");


				setTimeout(() => {

					openPage("home");

				}, 800);


			} else {

				showToast(data.message, "error");

			}


		});

}


// ===============================
// REGISTER
// ===============================

function registerUser() {

	const fullname = document.getElementById("fullname").value.trim();
	const phone = document.getElementById("phone").value.trim();
	const password = document.getElementById("reg_password").value;
	const confirm = document.getElementById("confirm_password").value;
	const sponsor = document.getElementById("sponsor").value.trim();


	if (!fullname || !phone || !password) {

		showToast("Complete required fields", "error");
		return;

	}


	if (password !== confirm) {

		showToast("Password mismatch", "error");
		return;

	}


	requestJson("register.php", {
		full_name: fullname,
		phone: phone,
		password: password,
		sponsor: sponsor
	})
		.then(data => {


			if (data.success) {

				showToast("Account created");

				setTimeout(() => {

					openPage("login");

				}, 1000);


			} else {

				showToast(data.message, "error");

			}

		});

}


// ===============================
// REMEMBER USER
// ===============================

function loadRememberedUser() {

	const saved = localStorage.getItem("pat_username");

	const input = document.getElementById("username");

	if (saved && input) input.value = saved;

}


// ===============================
// TOAST
// ===============================

function showToast(message, type = "success") {

	const old = document.querySelector(".toast");

	if (old) old.remove();


	const toast = document.createElement("div");

	toast.className = "toast " + type;

	toast.innerHTML = message;

	document.body.appendChild(toast);


	setTimeout(() => {

		toast.classList.add("show");

	}, 100);


	setTimeout(() => {

		toast.classList.remove("show");

		setTimeout(() => {

			toast.remove();

		}, 300);

	}, 3000);

}


// ===============================
// PAT CALCULATOR
// ===============================

function calculatePAT() {

	const investment = Number(
		document.getElementById("investment").value
	);

	const dailyEl = document.getElementById("daily");
	const totalEl = document.getElementById("total");

	if (!investment || investment < 500) {
		if (dailyEl) dailyEl.innerText = "₱0";
		if (totalEl) totalEl.innerText = "₱0";
		return;
	}

	const rate = (tradeSettings.yieldPercent || 6) / 100;
	const daily = investment * rate;
	const total = daily * (tradeSettings.durationDays || 25);

	if (dailyEl) dailyEl.innerText =
		"₱" + daily.toLocaleString("en-US", {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		});

	if (totalEl) totalEl.innerText =
		"₱" + total.toLocaleString("en-US", {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		});

}


// ===============================
// AI INVESTMENT
// ===============================

function tradeNow() {
	const user = getCurrentUser();
	const investmentInput = document.getElementById("investment");
	const amount = Number(investmentInput ? investmentInput.value : 0);

	if (!user || !user.id) {
		showToast("Please log in first", "error");
		return;
	}

	if (!amount || amount < 500) {
		showToast("Minimum trade amount is ₱500", "error");
		return;
	}

	showToast("Redirecting to PayMongo...");

	requestJson("paymongo.php", {
		user_id: user.id || 0,
		user: user,
		amount: amount,
		currency: "PHP",
		description: "PAT Trade Activation - " + (user.full_name || "Trader"),
		payment_method_types: ["qrph"],
		success_url: window.location.origin + "/index.html?trade=success",
		cancel_url: window.location.origin + "/index.html?trade=cancel",
		return_url: window.location.origin + "/index.html?trade=success",
		redirect_url: window.location.origin + "/index.html?trade=success",
		test_mode: window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1"
	})
		.then(data => {
			if (!data.success) {
				showToast(data.message || "Unable to start trade", "error");
				return;
			}

			const redirectUrl = data.checkout_url || data.url;
			if (redirectUrl) {
				window.location.href = redirectUrl;
			} else {
				showToast("PayMongo payment link URL was not returned", "error");
			}
		})
		.catch(() => {
			showToast("Unable to start trade", "error");
		});
}

function startAIInvestment() {

	showToast("AI Trade Started");

}


// ===============================
// AI ANIMATION
// ===============================

function startAIAnimation() {

	const status = document.querySelector(".ai-status");

	if (!status) return;


	aiStatusInterval = setInterval(() => {

		status.style.opacity = ".4";

		setTimeout(() => {

			status.style.opacity = "1";

		}, 500);


	}, 2500);

}


// ===============================
// PORTFOLIO COUNTER
// ===============================

function startPortfolioCounter(target) {

	const display = document.getElementById("portfolioAmount");

	if (!display) return;

	let value = 0;
	const finalValue = Number(target) || 0;

	if (finalValue <= 0) {
		display.textContent = "₱0.00";
		return;
	}

	const timer = setInterval(() => {

		value += Math.max(finalValue / 30, 1);

		if (value >= finalValue) {

			value = finalValue;
			clearInterval(timer);

		}

		display.textContent = "₱" + value.toLocaleString("en-US", {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		});

	}, 20);

}

function logoutUser() {
	localStorage.removeItem("pat_user");
	showToast("Logged out");
	setTimeout(() => {
		openPage("login");
	}, 800);
}

function populateSponsorFromQuery() {
	const params = new URLSearchParams(window.location.search);
	const referralCode = params.get("ref");
	const sponsorInput = document.getElementById("sponsor");

	if (sponsorInput && referralCode) {
		sponsorInput.value = referralCode;
	}
}

function copyReferralLink() {
	const input = document.getElementById("referralLinkInput");
	if (!input) return;

	input.select();
	input.setSelectionRange(0, input.value.length);

	navigator.clipboard.writeText(input.value)
		.then(() => showToast("Referral link copied"))
		.catch(() => showToast("Copy failed", "error"));
}

function loadDashboardData(isProfilePage = false) {
	const user = getCurrentUser();

	if (!user || !user.id) {
		showToast("Please log in first", "error");
		setTimeout(() => openPage("login"), 800);
		return;
	}

	requestJson("dashboard.php", { user_id: user.id })
		.then(data => {
			if (!data.success) {
				showToast(data.message || "Unable to load dashboard", "error");
				return;
			}

			const stats = data.stats || {};
			const userInfo = data.user || {};

			const portfolioDisplay = document.getElementById("portfolioAmount");
			if (portfolioDisplay) {
				startPortfolioCounter(Number(stats.portfolio_amount || 0));
			}

			const portfolioGain = document.getElementById("portfolioGain");
			if (portfolioGain) {
				const gainValue = Number(stats.computed_gain || 0);
				portfolioGain.innerHTML = '<span class="material-symbols-rounded"> trending_up </span> +' + gainValue.toFixed(2) + "% Today";
			}

			const welcomeName = document.getElementById("welcomeName");
			if (welcomeName) {
				welcomeName.textContent = "Welcome, " + (userInfo.full_name || "Trader");
			}

			const profileInitial = document.getElementById("profileInitial");
			if (profileInitial) {
				profileInitial.textContent = (userInfo.full_name || "P").charAt(0).toUpperCase();
			}

			const profileName = document.getElementById("profileName");
			if (profileName) {
				profileName.textContent = userInfo.full_name || "User";
			}

			const profileRole = document.getElementById("profileRole");
			if (profileRole) {
				profileRole.textContent = "Referral Code: " + (userInfo.referral_code || "N/A");
			}

			const profileStatus = document.getElementById("profileStatus");
			if (profileStatus) {
				const isActive = String(userInfo.is_active || userInfo.status || "inactive").toLowerCase() === "active";
				const statusText = ((userInfo.status || "inactive").toUpperCase()) + " MEMBER";
				profileStatus.textContent = statusText;
				profileStatus.style.color = isActive ? "#34A853" : "#EA4335";
			}

			const detailFullName = document.getElementById("detailFullName");
			if (detailFullName) {
				detailFullName.textContent = userInfo.full_name || "-";
			}

			const detailPhone = document.getElementById("detailPhone");
			if (detailPhone) {
				detailPhone.textContent = userInfo.phone || "-";
			}

			const detailReferral = document.getElementById("detailReferral");
			if (detailReferral) {
				detailReferral.textContent = userInfo.referral_code || "-";
			}

			const detailSponsor = document.getElementById("detailSponsor");
			if (detailSponsor) {
				detailSponsor.textContent = userInfo.sponsor_name || "-";
			}

			const referralLinkInput = document.getElementById("referralLinkInput");
			if (referralLinkInput) {
				const referralCode = userInfo.referral_code || "";
				referralLinkInput.value = referralCode
					? window.location.origin + "/index.html?ref=" + referralCode
					: "";
			}

			if (!isProfilePage) {
				const accuracyEl = document.getElementById("aiAccuracyValue");
				const yieldEl = document.getElementById("dailyYieldValue");
				const cycleEl = document.getElementById("daysCycleValue");

				if (accuracyEl) accuracyEl.textContent = (stats.ai_accuracy || 96) + "%";
				if (yieldEl) yieldEl.textContent = (stats.daily_yield || 6) + "%";
				if (cycleEl) cycleEl.textContent = (stats.days_cycle || 25);

				const planLabel = document.getElementById("planInfo");
				if (planLabel) {
					planLabel.textContent = "AI Confidence " + (stats.ai_confidence || 96) + "% • " + (stats.plan_name || "Prime Autonomous Trading");
				}
			}
		});
}

function loadTradeData() {
	const user = getCurrentUser();

	if (!user || !user.id) {
		return;
	}

	requestJson("dashboard.php", { user_id: user.id })
		.then(data => {
			if (!data.success) return;

			const stats = data.stats || {};
			tradeSettings = {
				yieldPercent: Number(stats.daily_yield || 6),
				durationDays: Number(stats.days_cycle || 25)
			};

			const yieldLabel = document.getElementById("tradeYieldValue");
			if (yieldLabel) {
				yieldLabel.textContent = (tradeSettings.yieldPercent || 6) + "%";
			}

			const cycleLabel = document.getElementById("tradeCycleLabel");
			if (cycleLabel) {
				cycleLabel.textContent = (tradeSettings.durationDays || 25) + " Day Return";
			}

			const planInfo = document.getElementById("tradePlanInfo");
			if (planInfo) {
				planInfo.textContent = (stats.plan_name || "Prime Autonomous Trading") + " • Min ₱" + Number(stats.plan_amount || 500).toLocaleString("en-US");
			}

			const activePlansContainer = document.getElementById("activePlansContainer");
			if (activePlansContainer) {
				const investments = stats.investments || [];
				const activeInvestments = investments.filter(item => String(item.status || "").toLowerCase() === "running");

				if (!activeInvestments.length) {
					activePlansContainer.innerHTML = "";
					return;
				}

				activePlansContainer.innerHTML = activeInvestments.map(item => `
					<div class="card">
					 <h3>Active Trade</h3>
					 <br>
					 <div class="row">
					  <span>Status</span>
					  <strong style="color:#34A853">${(item.status || "running").toUpperCase()}</strong>
					 </div>
					 <div class="row">
					  <span>Plan</span>
					  <strong>${item.plan_name || "Prime Autonomous Trading"}</strong>
					 </div>
					 <div class="row">
					  <span>Amount</span>
					  <strong>₱${Number(item.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
					 </div>
					 <div class="row">
					  <span>Daily Return</span>
					  <strong>${Number(item.daily_percent || 0)}%</strong>
					 </div>
					 <div class="row">
					  <span>Duration</span>
					  <strong>${Number(item.duration_days || 25)} Days</strong>
					 </div>
					</div>
				`).join('');
			}
		});
}

function loadAIData() {
	const user = getCurrentUser();

	if (!user || !user.id) {
		return;
	}

	requestJson("dashboard.php", { user_id: user.id })
		.then(data => {
			if (!data.success) return;

			const stats = data.stats || {};
			const aiStatus = document.getElementById("aiStatusValue");
			if (aiStatus) aiStatus.textContent = "ONLINE";

			const aiMode = document.getElementById("aiModeValue");
			if (aiMode) {
				aiMode.textContent = "● " + ((stats.plan_name || "Prime Autonomous Trading") + " Active");
			}

			const marketTrend = document.getElementById("marketTrendValue");
			if (marketTrend) {
				const trend = Number(stats.computed_gain || 0) > 0 ? "BULLISH" : "NEUTRAL";
				marketTrend.textContent = trend;
				marketTrend.style.color = trend === "BULLISH" ? "#34A853" : "#F9AB00";
			}

			const aiConfidence = document.getElementById("aiConfidenceValue");
			if (aiConfidence) {
				aiConfidence.textContent = (stats.ai_confidence || 96) + "%";
			}

			const riskLevel = document.getElementById("riskLevelValue");
			if (riskLevel) {
				const risk = Number(stats.computed_gain || 0) > 0 ? "LOW" : "MEDIUM";
				riskLevel.textContent = risk;
			}

			const strategy = document.getElementById("strategyValue");
			if (strategy) {
				strategy.textContent = stats.plan_name || "Prime Growth AI";
			}
		});
}

function loadWalletData() {
	const user = getCurrentUser();

	if (!user || !user.id) {
		showToast("Please log in first", "error");
		setTimeout(() => openPage("login"), 800);
		return;
	}

	requestJson("wallet.php", { user_id: user.id })
		.then(data => {
			if (!data.success) {
				showToast(data.message || "Unable to load wallet", "error");
				return;
			}

			const wallet = data.wallet || {};
			const transactions = data.transactions || [];

			const balanceEl = document.getElementById("walletBalance");
			if (balanceEl) {
				balanceEl.textContent = "₱" + Number(wallet.available_balance || 0).toLocaleString("en-US", {
					minimumFractionDigits: 2,
					maximumFractionDigits: 2
				});
			}

			const statusEl = document.getElementById("walletStatus");
			if (statusEl) {
				const isActive = data.user && data.user.is_active;
				const bonusValue = Number(wallet.referral_balance || 0) + Number(wallet.leadership_balance || 0);
				statusEl.innerHTML = isActive
					? '<span class="material-symbols-rounded"> trending_up </span> +₱' + bonusValue.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' bonus'
					: '<span class="material-symbols-rounded"> block </span> Membership inactive';
			}

			const withdrawStatusEl = document.getElementById("withdrawStatus");
			if (withdrawStatusEl) {
				const isActive = data.user && data.user.is_active;
				withdrawStatusEl.textContent = isActive ? 'Instant ⚡' : 'Blocked';
				withdrawStatusEl.style.color = isActive ? '#34A853' : '#EA4335';
			}

			const withdrawButtonEl = document.getElementById("withdrawButton");
			if (withdrawButtonEl) {
				withdrawButtonEl.disabled = !(data.user && data.user.is_active);
				withdrawButtonEl.style.opacity = (data.user && data.user.is_active) ? '1' : '0.6';
			}

			const tradeEl = document.getElementById("walletTradeValue");
			if (tradeEl) {
				tradeEl.textContent = "₱" + Number(wallet.invested_balance || 0).toLocaleString("en-US", {
					minimumFractionDigits: 2,
					maximumFractionDigits: 2
				});
			}

			const profitEl = document.getElementById("walletProfitValue");
			if (profitEl) {
				profitEl.textContent = "₱" + Number(wallet.profit_balance || 0).toLocaleString("en-US", {
					minimumFractionDigits: 2,
					maximumFractionDigits: 2
				});
			}

			const bonusEl = document.getElementById("walletBonusValue");
			if (bonusEl) {
				const bonusTotal = Number(wallet.referral_balance || 0) + Number(wallet.leadership_balance || 0);
				bonusEl.textContent = "₱" + bonusTotal.toLocaleString("en-US", {
					minimumFractionDigits: 2,
					maximumFractionDigits: 2
				});
			}

			const listEl = document.getElementById("transactionList");
			if (listEl) {
				if (!transactions.length) {
					listEl.innerHTML = '<div class="row"><span>No transactions yet</span></div>';
					return;
				}

				listEl.innerHTML = transactions.map(txn => {
					const isCredit = txn.type === 'deposit' || txn.type === 'bonus';
					const amountText = (isCredit ? '+' : '-') + '₱' + Number(txn.amount || 0).toLocaleString("en-US", {
						minimumFractionDigits: 2,
						maximumFractionDigits: 2
					});
					const color = isCredit ? '#34A853' : '#EA4335';
					const statusText = txn.status ? ` • ${txn.status.toUpperCase()}` : '';
					return `<div class="row"><span>${txn.type === 'deposit' ? 'Deposit' : txn.type === 'withdrawal' ? 'Withdrawal' : txn.type}${statusText}</span><strong style="color:${color}">${amountText}</strong></div>`;
				}).join('');
			}
		});
}

function requestWalletWithdrawal() {
	const user = JSON.parse(localStorage.getItem("pat_user") || "null");
	const amountInput = document.getElementById("withdrawAmount");
	const amount = Number(amountInput ? amountInput.value : 0);

	if (!user || !user.id) {
		showToast("Please log in first", "error");
		return;
	}

	if (!amount || amount < 200) {
		showToast("Minimum withdrawal amount is ₱200", "error");
		return;
	}

	requestJson("wallet.php", { user_id: user.id, action: 'request_withdrawal', amount: amount })
		.then(data => {
			showToast(data.message || "Withdrawal request submitted", data.success ? "success" : "error");
			if (data.success) {
				if (amountInput) amountInput.value = "";
				loadWalletData();
			}
		});
}


// ===============================
// START APP
// ===============================

window.onload = () => {

	const bottomNav = document.getElementById("bottomNav");

	if (bottomNav) bottomNav.style.display = "none";

	const params = new URLSearchParams(window.location.search);
	const tradeResult = params.get("trade");

	if (tradeResult === "success") {
		showToast("Trade payment completed. Your investment will activate once PayMongo confirms payment.", "success");
	} else if (tradeResult === "cancel") {
		showToast("Trade payment was cancelled.", "error");
	}

	if (tradeResult) {
		params.delete("trade");
		const newSearch = params.toString();
		history.replaceState(null, "", window.location.pathname + (newSearch ? `?${newSearch}` : ""));
	}

	const savedUser = JSON.parse(localStorage.getItem("pat_user") || "null");

	if (savedUser && savedUser.id) {
		openPage("home");
	} else {
		openPage("login");
	}

};