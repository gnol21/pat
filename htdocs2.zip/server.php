<?php

declare(strict_types=1);

function getDatabaseConnection(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = '127.0.0.1';
    $db   = 'prime_autonomous_trading';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        return $pdo;
    } catch (PDOException $e) {
        sendJsonResponse(false, 'Database connection failed.');
    }
}

function sendJsonResponse(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message,
    ], $extra));
    exit;
}

function getJsonInput(): array
{
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    if (!is_array($data)) {
        $data = $_POST;
    }

    return is_array($data) ? $data : [];
}

function getPaymongoSecretKey(): string
{
    $candidates = [];
    $envNames = ['PAYMONGO_SECRET_KEY', 'PAYMONGO_SECRET', 'PAYMONGO_LIVE_SECRET_KEY', 'PAYMONGO_TEST_SECRET_KEY'];

    foreach ($envNames as $envName) {
        $value = getenv($envName);
        if ($value !== false && trim((string)$value) !== '') {
            $candidates[] = trim((string)$value);
        }

        if (isset($_ENV[$envName]) && trim((string)$_ENV[$envName]) !== '') {
            $candidates[] = trim((string)$_ENV[$envName]);
        }

        if (isset($_SERVER[$envName]) && trim((string)$_SERVER[$envName]) !== '') {
            $candidates[] = trim((string)$_SERVER[$envName]);
        }
    }

    if (!empty($candidates)) {
        return $candidates[0];
    }

    $dotenvPath = __DIR__ . '/.env';
    if (is_file($dotenvPath)) {
        $lines = file($dotenvPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }

                if (strpos($line, '=') === false) {
                    continue;
                }

                [$key, $value] = array_map('trim', explode('=', $line, 2));
                $key = trim($key);
                $value = trim($value);

                if ($key === '' || $value === '') {
                    continue;
                }

                if (in_array($key, $envNames, true)) {
                    return $value;
                }
            }
        }
    }

    return '';
}

function getPaymongoWebhookSecret(): string
{
    $envNames = ['PAYMONGO_WEBHOOK_SECRET', 'PAYMONGO_WH_SECRET', 'PAYMONGO_WEBHOOK_KEY', 'PAYMONGO_WEBHOOK_SECRET'];
    foreach ($envNames as $envName) {
        $val = getenv($envName);
        if ($val !== false && trim((string)$val) !== '') {
            return trim((string)$val);
        }
        if (isset($_ENV[$envName]) && trim((string)$_ENV[$envName]) !== '') {
            return trim((string)$_ENV[$envName]);
        }
        if (isset($_SERVER[$envName]) && trim((string)$_SERVER[$envName]) !== '') {
            return trim((string)$_SERVER[$envName]);
        }
    }

    $dotenvPath = __DIR__ . '/.env';
    if (is_file($dotenvPath)) {
        $lines = file($dotenvPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }
                if (strpos($line, '=') === false) continue;
                [$key, $value] = array_map('trim', explode('=', $line, 2));
                if (in_array($key, $envNames, true)) return $value;
            }
        }
    }

    return '';
}
?>
