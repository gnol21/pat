<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
$action = isset($data['action']) ? strtolower((string)$data['action']) : '';

if ($userId <= 0) {
    sendJsonResponse(false, 'User not found.');
}

if ($action === 'request_withdrawal') {
    $amount = isset($data['amount']) ? (float)$data['amount'] : 0;

    $userStatusStmt = $pdo->prepare('SELECT status FROM users WHERE id = ? LIMIT 1');
    $userStatusStmt->execute([$userId]);
    $member = $userStatusStmt->fetch();
    $isActiveMember = $member && strtolower((string)$member['status']) === 'active';

    if (!$isActiveMember) {
        sendJsonResponse(false, 'Withdrawal is disabled until the member becomes active after a trade.');
    }

    if ($amount < 200) {
        sendJsonResponse(false, 'Minimum withdrawal amount is ₱200.');
    }

    try {
        $walletStmt = $pdo->prepare('SELECT deposit_balance, profit_balance, referral_balance, leadership_balance FROM wallets WHERE user_id = ? LIMIT 1');
        $walletStmt->execute([$userId]);
        $wallet = $walletStmt->fetch();

        $depositBal = $wallet ? (float)$wallet['deposit_balance'] : 0.0;
        $profitBal = $wallet ? (float)$wallet['profit_balance'] : 0.0;
        $referralBal = $wallet ? (float)$wallet['referral_balance'] : 0.0;
        $leadershipBal = $wallet ? (float)$wallet['leadership_balance'] : 0.0;

        // available balance is the sum of all income components and is the only withdrawable amount
        $availableBalance = $depositBal + $profitBal + $referralBal + $leadershipBal;

        if ($availableBalance < $amount) {
            sendJsonResponse(false, 'Insufficient balance.');
        }

        $insertStmt = $pdo->prepare(
            'INSERT INTO withdrawals (user_id, amount, status, created_at) VALUES (?, ?, ?, NOW())'
        );
        $insertStmt->execute([$userId, $amount, 'pending']);

        sendJsonResponse(true, 'Withdrawal request submitted.', [
            'withdrawal_id' => (int)$pdo->lastInsertId(),
        ]);
    } catch (PDOException $e) {
        sendJsonResponse(false, 'Unable to submit withdrawal request.');
    }
}

try {
    $userStmt = $pdo->prepare('SELECT id, balance, status FROM users WHERE id = ? LIMIT 1');
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch();

    $investmentsStmt = $pdo->prepare(
        'SELECT id FROM investments WHERE user_id = ? LIMIT 1'
    );
    $investmentsStmt->execute([$userId]);
    $investments = $investmentsStmt->fetchAll();
    $hasTrade = count($investments) > 0;

    if ($user && $user['status'] !== 'active' && $hasTrade) {
        $updateUserStatus = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $updateUserStatus->execute(['active', $userId]);
        $user['status'] = 'active';
    } elseif ($user && $user['status'] === 'active' && !$hasTrade) {
        $updateUserStatus = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $updateUserStatus->execute(['inactive', $userId]);
        $user['status'] = 'inactive';
    }

    $walletStmt = $pdo->prepare(
        'SELECT deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1'
    );
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();

    // Compute available balance as the sum of all income components — this is the only withdrawable balance
    $depositBal = $wallet ? (float)$wallet['deposit_balance'] : 0.0;
    $profitBal = $wallet ? (float)$wallet['profit_balance'] : 0.0;
    $referralBal = $wallet ? (float)$wallet['referral_balance'] : 0.0;
    $leadershipBal = $wallet ? (float)$wallet['leadership_balance'] : 0.0;

    $availableBalance = $depositBal + $profitBal + $referralBal + $leadershipBal;
    if ($availableBalance <= 0) {
        $availableBalance = $user ? (float)$user['balance'] : 0.0;
    }

    $investmentsTotalStmt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total_invested FROM investments WHERE user_id = ?');
    $investmentsTotalStmt->execute([$userId]);
    $investmentsTotalRow = $investmentsTotalStmt->fetch();
    $investedBalance = $investmentsTotalRow ? (float)$investmentsTotalRow['total_invested'] : 0.0;

    $portfolioAmount = $availableBalance + $investedBalance;

    $depositStmt = $pdo->prepare(
        'SELECT amount, status, created_at FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 5'
    );
    $depositStmt->execute([$userId]);
    $deposits = $depositStmt->fetchAll();

    $withdrawalStmt = $pdo->prepare(
        'SELECT amount, status, created_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 5'
    );
    $withdrawalStmt->execute([$userId]);
    $withdrawals = $withdrawalStmt->fetchAll();

    $transactions = [];

    foreach ($deposits as $deposit) {
        $transactions[] = [
            'type' => 'deposit',
            'amount' => (float)$deposit['amount'],
            'status' => $deposit['status'],
            'created_at' => $deposit['created_at'],
        ];
    }

    foreach ($withdrawals as $withdrawal) {
        $transactions[] = [
            'type' => 'withdrawal',
            'amount' => (float)$withdrawal['amount'],
            'status' => $withdrawal['status'],
            'created_at' => $withdrawal['created_at'],
        ];
    }

    usort($transactions, function ($a, $b) {
        return strtotime($b['created_at']) <=> strtotime($a['created_at']);
    });

    $transactions = array_slice($transactions, 0, 6);

    $userStatusStmt = $pdo->prepare('SELECT status FROM users WHERE id = ? LIMIT 1');
    $userStatusStmt->execute([$userId]);
    $member = $userStatusStmt->fetch();
    $isActiveMember = $member && strtolower((string)$member['status']) === 'active';

    sendJsonResponse(true, 'Wallet loaded.', [
        'user' => [
            'is_active' => $isActiveMember,
            'status' => $member ? $member['status'] : 'inactive',
        ],
        'wallet' => [
            'available_balance' => $availableBalance,
            'invested_balance' => $investedBalance,
            'deposit_balance' => $wallet ? (float)$wallet['deposit_balance'] : 0.0,
            'profit_balance' => $wallet ? (float)$wallet['profit_balance'] : 0.0,
            'referral_balance' => $wallet ? (float)$wallet['referral_balance'] : 0.0,
            'leadership_balance' => $wallet ? (float)$wallet['leadership_balance'] : 0.0,
            'total_balance' => $portfolioAmount,
        ],
        'transactions' => $transactions,
    ]);
} catch (PDOException $e) {
    sendJsonResponse(false, 'Unable to load wallet data.');
}
?>
