<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$username = trim((string)($data['username'] ?? ''));
$password = (string)($data['password'] ?? '');

if ($username === '' || $password === '') {
    sendJsonResponse(false, 'Enter username and password.');
}

try {
    $stmt = $pdo->prepare(
        'SELECT id, full_name, phone, password, referral_code, status FROM users WHERE full_name = ? OR phone = ? LIMIT 1'
    );
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();

    if (!$user) {
        sendJsonResponse(false, 'Invalid username or password.');
    }

    if ($user['status'] !== 'active') {
        sendJsonResponse(false, 'Your account is not active.');
    }

    if (!password_verify($password, $user['password'])) {
        sendJsonResponse(false, 'Invalid username or password.');
    }

    sendJsonResponse(true, 'Login successful.', [
        'user' => [
            'id' => (int)$user['id'],
            'full_name' => $user['full_name'],
            'phone' => $user['phone'],
            'referral_code' => $user['referral_code'],
        ],
    ]);
} catch (PDOException $e) {
    sendJsonResponse(false, 'Unable to sign in right now: ' . $e->getMessage());
}
?>
