<?php
header('Content-Type: application/json');
require_once 'server.php';

$webhookSecret = getPaymongoWebhookSecret();
$secretLoaded = $webhookSecret !== '';
$acceptedEvents = [
    'checkout.session.completed',
    'checkout.session.payment.paid',
    'checkout_session.completed',
    'checkout_session.payment.paid',
    'checkout_session',
    'checkout.session',
];

$secretPrefix = $secretLoaded ? substr($webhookSecret, 0, 8) : null;
$response = [
    'success' => true,
    'message' => 'PayMongo webhook diagnostics',
    'webhook' => [
        'secret_loaded' => $secretLoaded,
        'secret_length' => $secretLoaded ? strlen($webhookSecret) : 0,
        'secret_prefix' => $secretPrefix,
        'accepted_events' => $acceptedEvents,
        'webhook_endpoint' => 'paymongo_webhook.php',
    ],
    'environment' => [
        'php_version' => PHP_VERSION,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? null,
        'request_method' => $_SERVER['REQUEST_METHOD'] ?? null,
    ],
];

echo json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
