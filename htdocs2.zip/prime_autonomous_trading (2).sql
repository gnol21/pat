-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2026 at 08:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prime_autonomous_trading`
--

-- --------------------------------------------------------

--
-- Table structure for table `daily_profits`
--

CREATE TABLE `daily_profits` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `investment_id` int(11) NOT NULL,
  `profit_amount` decimal(15,2) DEFAULT NULL,
  `profit_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `user_id`, `amount`, `payment_method`, `transaction_id`, `status`, `created_at`) VALUES
(5, 6, 500.00, 'paymongo', 'evt_test_valid', 'approved', '2026-07-24 02:02:42'),
(7, 4, 5000.00, 'paymongo', 'pi_TxotJXXFtzfPP3yTc8Ddmfgc', 'approved', '2026-07-24 03:24:40'),
(10, 6, 500.00, 'paymongo', 'pi_sim_001', 'approved', '2026-07-24 05:29:46'),
(11, 9, 1200.00, 'paymongo', 'pi_A9PCRCo8YAu9KZPPzQLQgpnG', 'approved', '2026-07-24 05:38:14'),
(12, 9, 500.00, 'paymongo', 'pi_fz7QouSmWrAYdWAg4ng39Eip', 'approved', '2026-07-24 05:40:33'),
(27, 4, 500.00, 'paymongo', 'pi_DAjXZaJkNmRNZZmSQpCGcWP6', 'approved', '2026-07-24 06:15:30'),
(35, 9, 1200.00, 'paymongo', 'pi_Vb4xw98n3PfV3TMJXQ987eKa', 'approved', '2026-07-24 06:18:50'),
(37, 10, 500.00, 'paymongo', 'pi_6fhmKk9sMqZH8TZbfJSsexxX', 'approved', '2026-07-24 06:21:38'),
(39, 10, 800.00, 'paymongo', 'pi_bWcU8mHidANkhpEnKQsVKrtf', 'approved', '2026-07-24 06:23:21'),
(40, 11, 1000.00, 'paymongo', 'pi_vaZRC6hs2ry5gkANyWcJ4o89', 'approved', '2026-07-24 06:24:08');

-- --------------------------------------------------------

--
-- Table structure for table `investments`
--

CREATE TABLE `investments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `daily_profit` decimal(15,2) NOT NULL,
  `total_profit` decimal(15,2) DEFAULT 0.00,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('running','completed','cancelled') DEFAULT 'running',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investments`
--

INSERT INTO `investments` (`id`, `user_id`, `plan_id`, `amount`, `daily_profit`, `total_profit`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(5, 4, 1, 5000.00, 300.00, 7500.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 03:24:40'),
(8, 6, 1, 500.00, 30.00, 750.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 05:29:46'),
(9, 9, 1, 1200.00, 72.00, 1800.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 05:38:14'),
(10, 9, 1, 500.00, 30.00, 750.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 05:40:33'),
(11, 4, 1, 500.00, 30.00, 750.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 06:15:30'),
(12, 10, 1, 500.00, 30.00, 750.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 06:21:38'),
(13, 10, 1, 800.00, 48.00, 1200.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 06:23:21'),
(14, 11, 1, 1000.00, 60.00, 1500.00, '2026-07-24', '2026-08-18', 'running', '2026-07-24 06:24:08');

-- --------------------------------------------------------

--
-- Table structure for table `investment_plans`
--

CREATE TABLE `investment_plans` (
  `id` int(11) NOT NULL,
  `plan_name` varchar(100) NOT NULL,
  `minimum_amount` decimal(15,2) DEFAULT 500.00,
  `daily_profit_percent` decimal(5,2) DEFAULT 6.00,
  `duration_days` int(11) DEFAULT 25,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investment_plans`
--

INSERT INTO `investment_plans` (`id`, `plan_name`, `minimum_amount`, `daily_profit_percent`, `duration_days`, `status`, `created_at`) VALUES
(1, 'Prime Autonomous Trading', 500.00, 6.00, 25, 'active', '2026-07-23 01:19:24');

-- --------------------------------------------------------

--
-- Table structure for table `leadership_bonus`
--

CREATE TABLE `leadership_bonus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `bonus_amount` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referral_bonus`
--

CREATE TABLE `referral_bonus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `referred_user_id` int(11) NOT NULL,
  `investment_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `bonus_amount` decimal(15,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `minimum_investment` decimal(15,2) DEFAULT 500.00,
  `minimum_withdrawal` decimal(15,2) DEFAULT 200.00,
  `daily_profit_percent` decimal(5,2) DEFAULT 6.00,
  `investment_duration` int(11) DEFAULT 25,
  `referral_level1` decimal(5,2) DEFAULT 5.00,
  `referral_level2` decimal(5,2) DEFAULT 3.00,
  `referral_level3` decimal(5,2) DEFAULT 2.00,
  `referral_level4` decimal(5,2) DEFAULT 1.00,
  `referral_level5` decimal(5,2) DEFAULT 1.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `minimum_investment`, `minimum_withdrawal`, `daily_profit_percent`, `investment_duration`, `referral_level1`, `referral_level2`, `referral_level3`, `referral_level4`, `referral_level5`, `created_at`) VALUES
(1, 500.00, 200.00, 6.00, 25, 5.00, 3.00, 2.00, 1.00, 1.00, '2026-07-23 01:19:24');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdrawal','investment','profit','referral','leadership') DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `sponsor_id` int(11) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `referral_code` varchar(20) NOT NULL,
  `status` enum('active','inactive','blocked') DEFAULT 'inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `sponsor_id`, `full_name`, `phone`, `password`, `balance`, `referral_code`, `status`, `created_at`) VALUES
(3, NULL, 'Admin', '0000000000', '$2y$10$bD5F3s1RDm6wYYnGDsp8CO3gwtWR3voshBZqQuSHWCwESSHsv5npa', 0.00, 'ADMIN', 'active', '2026-07-23 01:34:48'),
(4, 3, 'long empasis', '09126000785', '$2y$10$kbUw7ImXgxFg9J.VA5sl7eRIX/CzwS8eii31j.fdYB6pwIN8evpuK', 0.00, 'LON0785812', 'active', '2026-07-23 01:34:48'),
(6, 4, 'rey dg', '09682651743', '$2y$10$dUem8uRU00wLU8tzJWdXveix1AFpNsKqgHHrg.Ll0H3ToFct7zGFa', 0.00, 'REY1743205', 'active', '2026-07-23 01:55:54'),
(7, 4, 'Reydg', '09682651743', '$2y$10$lCTAF0a0Bo4y5TzFDbn2LO3LddEwnzUvwtUoGmhmpnrjAiIXcMMqa', 0.00, 'REY1743974', 'inactive', '2026-07-24 00:59:40'),
(8, 3, 'jhack', '09126000785', '$2y$10$2YgElhM7NYhWtLw9akGImOdPxVSzL5ZHvnkw2UIPnD.0y8slOXRci', 0.00, 'JHA0785971', 'inactive', '2026-07-24 03:01:56'),
(9, 3, 'test1', '09126000785', '$2y$10$QsLXkNPqPiZywK/PAUbc1.B0YGD97Oa1UNNjButjLHXpBh9BBze6i', 0.00, 'TES0785898', 'active', '2026-07-24 05:36:45'),
(10, 3, 'romulo empasis', '09126000785', '$2y$10$Ggjjjd3ztDoN57DncL8UMuo7P8X/.9AxrWVUj/1eqvidmSS.LhNJa', 0.00, 'ROM0785685', 'active', '2026-07-24 06:20:53'),
(11, 10, 'user1', '09126000785', '$2y$10$7ssSUPSKC.8HqNN5Lzv28epbqCbuKGIuzgYueWNpyGTUticwmFutO', 0.00, 'USE0785209', 'active', '2026-07-24 06:23:19');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deposit_balance` decimal(15,2) DEFAULT 0.00,
  `profit_balance` decimal(15,2) DEFAULT 0.00,
  `referral_balance` decimal(15,2) DEFAULT 0.00,
  `leadership_balance` decimal(15,2) DEFAULT 0.00,
  `total_balance` decimal(15,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `deposit_balance`, `profit_balance`, `referral_balance`, `leadership_balance`, `total_balance`) VALUES
(1, 1, 0.00, 0.00, 0.00, 0.00, 0.00),
(2, 2, 0.00, 0.00, 0.00, 0.00, 0.00),
(3, 4, 5500.00, 0.00, 0.00, 0.00, 5500.00),
(4, 5, 0.00, 0.00, 0.00, 0.00, 0.00),
(5, 6, 3500.00, 0.00, 0.00, 0.00, 3500.00),
(6, 7, 0.00, 0.00, 0.00, 0.00, 0.00),
(7, 8, 0.00, 0.00, 0.00, 0.00, 0.00),
(8, 9, 2900.00, 0.00, 0.00, 0.00, 2900.00),
(9, 10, 1300.00, 0.00, 0.00, 0.00, 1300.00),
(10, 11, 1000.00, 0.00, 0.00, 0.00, 1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `wallet_address` varchar(255) DEFAULT NULL,
  `process_type` varchar(50) DEFAULT 'instant',
  `status` enum('pending','approved','completed','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daily_profits`
--
ALTER TABLE `daily_profits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `investment_id` (`investment_id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `investments`
--
ALTER TABLE `investments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `investment_plans`
--
ALTER TABLE `investment_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leadership_bonus`
--
ALTER TABLE `leadership_bonus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `referral_bonus`
--
ALTER TABLE `referral_bonus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `referred_user_id` (`referred_user_id`),
  ADD KEY `investment_id` (`investment_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `full_name` (`full_name`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `sponsor_id` (`sponsor_id`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daily_profits`
--
ALTER TABLE `daily_profits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `investments`
--
ALTER TABLE `investments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `investment_plans`
--
ALTER TABLE `investment_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leadership_bonus`
--
ALTER TABLE `leadership_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referral_bonus`
--
ALTER TABLE `referral_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `daily_profits`
--
ALTER TABLE `daily_profits`
  ADD CONSTRAINT `daily_profits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `daily_profits_ibfk_2` FOREIGN KEY (`investment_id`) REFERENCES `investments` (`id`);

--
-- Constraints for table `deposits`
--
ALTER TABLE `deposits`
  ADD CONSTRAINT `deposits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `investments`
--
ALTER TABLE `investments`
  ADD CONSTRAINT `investments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `investments_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `investment_plans` (`id`);

--
-- Constraints for table `leadership_bonus`
--
ALTER TABLE `leadership_bonus`
  ADD CONSTRAINT `leadership_bonus_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `referral_bonus`
--
ALTER TABLE `referral_bonus`
  ADD CONSTRAINT `referral_bonus_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `referral_bonus_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `referral_bonus_ibfk_3` FOREIGN KEY (`investment_id`) REFERENCES `investments` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`sponsor_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `withdrawals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
