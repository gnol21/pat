﻿<?php
$host = '127.0.0.1';
$db   = 'prime_autonomous_trading';
$user = 'root';
$pass = '';
$pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
$tables = ['withdrawals','settings'];
foreach ($tables as $table) {
    echo "--- $table ---\n";
    try {
        $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
        $row = $stmt->fetch();
        echo $row['Create Table'] . "\n";
    } catch (PDOException $e) {
        echo "MISSING: " . $e->getMessage() . "\n";
    }
}
?>
