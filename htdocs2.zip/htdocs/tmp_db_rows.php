﻿<?php
$host = '127.0.0.1';
$db   = 'prime_autonomous_trading';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
$pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
foreach (['deposits','wallets','investments'] as $table) {
    echo "--- $table ---\n";
    $stmt = $pdo->query("SELECT * FROM $table LIMIT 10");
    $rows = $stmt->fetchAll();
    foreach ($rows as $r) {
        echo json_encode($r) . "\n";
    }
}
?>
