﻿<?php
$secret = 'whsk_4EtB3rBmim22fXVyV3v2Ck6e';
$payload = file_get_contents('C:/xampp/htdocs/tmp_payload2.json');
$timestamp = '1785324023';
echo hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
?>
