<?php
require_once 'server.php';

$pdo = getDatabaseConnection();

// Ensure process_status table exists (lightweight run-time migration)
$pdo->exec("CREATE TABLE IF NOT EXISTS process_status (
    name VARCHAR(100) PRIMARY KEY,
    last_run DATETIME NULL,
    last_success TINYINT(1) DEFAULT 0,
    last_message TEXT NULL,
    last_duration_seconds INT NULL,
    last_count INT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// Acquire a named DB lock to prevent concurrent runs
$lockName = 'process_daily_payouts_lock';
$gotLock = 0;
try {
    $stmtLock = $pdo->prepare("SELECT GET_LOCK(?, 0) AS got");
    $stmtLock->execute([$lockName]);
    $rowLock = $stmtLock->fetch();
    $gotLock = isset($rowLock['got']) ? (int)$rowLock['got'] : 0;
} catch (Throwable $e) {
    error_log('Lock acquisition failed: ' . $e->getMessage());
}

if ($gotLock !== 1) {
    // Another process is running — exit gracefully
    echo "Another instance is running, exiting.\n";
    exit(0);
}

$startTime = microtime(true);
$startDt = new DateTimeImmutable('now', new DateTimeZone('Asia/Manila'));
$startSql = $startDt->format('Y-m-d H:i:s');

$processedCount = 0;
$lastMessage = 'OK';
$success = 1;

try {
    $now = new DateTimeImmutable('now', new DateTimeZone('Asia/Manila'));
    $nowSql = $now->format('Y-m-d H:i:s');

    $selectStmt = $pdo->prepare(
        "SELECT i.id, i.user_id, i.amount, i.daily_profit, i.next_payout_at, i.end_date, i.status
         FROM investments i
         WHERE i.status = 'running'
           AND i.next_payout_at IS NOT NULL
           AND i.next_payout_at <= ?"
    );
    $selectStmt->execute([$nowSql]);
    $investments = $selectStmt->fetchAll();

    foreach ($investments as $investment) {
        $investmentId = (int)$investment['id'];
        $userId = (int)$investment['user_id'];
        $dailyProfit = (float)$investment['daily_profit'];
        $endDate = $investment['end_date'] ?? null;

        $isExpired = false;
        if ($endDate) {
            $endDateObj = new DateTimeImmutable((string)$endDate, new DateTimeZone('Asia/Manila'));
            $isExpired = $endDateObj < $now;
        }

        if ($isExpired) {
            $pdo->prepare("UPDATE investments SET status = 'completed', next_payout_at = NULL WHERE id = ?")
                ->execute([$investmentId]);
            continue;
        }

        $pdo->beginTransaction();
        try {
            $walletStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1');
            $walletStmt->execute([$userId]);
            $wallet = $walletStmt->fetch();

            if ($wallet) {
                $depositBal = (float)$wallet['deposit_balance'];
                $profitBal = (float)$wallet['profit_balance'];
                $referralBal = (float)$wallet['referral_balance'];
                $leadershipBal = (float)$wallet['leadership_balance'];

                $newProfitBalance = $profitBal + $dailyProfit;
                $newTotalBalance = $depositBal + $newProfitBalance + $referralBal + $leadershipBal;

                $pdo->prepare('UPDATE wallets SET profit_balance = ?, total_balance = ? WHERE id = ?')
                    ->execute([$newProfitBalance, $newTotalBalance, (int)$wallet['id']]);
            }

            $nextPayoutAt = $now->modify('+1 day')->setTime((int)$now->format('H'), (int)$now->format('i'), (int)$now->format('s'));
            $pdo->prepare('UPDATE investments SET next_payout_at = ? WHERE id = ?')
                ->execute([$nextPayoutAt->format('Y-m-d H:i:s'), $investmentId]);

            $pdo->commit();
            $processedCount++;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Daily payout failed for investment ' . $investmentId . ': ' . $e->getMessage());
            // continue with next investment
        }
    }
} catch (Throwable $e) {
    $success = 0;
    $lastMessage = 'Processor error: ' . $e->getMessage();
    error_log($lastMessage);
}

$duration = (int)round((microtime(true) - $startTime));

// Update process_status row
try {
    $upsert = $pdo->prepare("INSERT INTO process_status (name, last_run, last_success, last_message, last_duration_seconds, last_count) VALUES (?, ?, ?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE last_run = VALUES(last_run), last_success = VALUES(last_success), last_message = VALUES(last_message), last_duration_seconds = VALUES(last_duration_seconds), last_count = VALUES(last_count)");
    $upsert->execute(['process_daily_payouts', $startSql, $success, $lastMessage, $duration, $processedCount]);
} catch (Throwable $e) {
    error_log('Failed to update process_status: ' . $e->getMessage());
}

// Release lock
try {
    $stmtRel = $pdo->prepare("SELECT RELEASE_LOCK(?) AS released");
    $stmtRel->execute([$lockName]);
} catch (Throwable $e) {
    // ignore
}

echo "Processed " . $processedCount . " investment payout(s).\n";
