<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
$amount = isset($data['amount']) ? (float)$data['amount'] : 0.0;
$useAvailableBalance = !empty($data['use_available_balance']);

if ($userId <= 0) {
    sendJsonResponse(false, 'User not found.');
}

if ($amount < 500) {
    sendJsonResponse(false, 'Minimum trade amount is ₱500.');
}

try {
    $pdo->beginTransaction();

    $walletStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1');
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();

    if (!$wallet) {
        $createWallet = $pdo->prepare('INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, 0, 0, 0, 0, 0)');
        $createWallet->execute([$userId]);
        $walletId = (int)$pdo->lastInsertId();
        $wallet = [
            'id' => $walletId,
            'deposit_balance' => 0,
            'profit_balance' => 0,
            'referral_balance' => 0,
            'leadership_balance' => 0,
            'total_balance' => 0,
        ];
    }

    if ($useAvailableBalance) {
        $availableBalance = (float)$wallet['deposit_balance'] + (float)$wallet['profit_balance'] + (float)$wallet['referral_balance'] + (float)$wallet['leadership_balance'];
        if ($availableBalance < $amount) {
            $pdo->rollBack();
            sendJsonResponse(false, 'Insufficient available balance.');
        }

        $remaining = $amount;
        $debit = [
            'deposit_balance' => (float)$wallet['deposit_balance'],
            'profit_balance' => (float)$wallet['profit_balance'],
            'referral_balance' => (float)$wallet['referral_balance'],
            'leadership_balance' => (float)$wallet['leadership_balance'],
        ];

        foreach (['deposit_balance', 'profit_balance', 'referral_balance', 'leadership_balance'] as $column) {
            if ($remaining <= 0) {
                break;
            }
            $current = (float)$debit[$column];
            if ($current <= 0) {
                continue;
            }
            $used = min($current, $remaining);
            $debit[$column] = $current - $used;
            $remaining -= $used;
        }

        if ($remaining > 0.000001) {
            $pdo->rollBack();
            sendJsonResponse(false, 'Insufficient available balance.');
        }

        $newTotal = $debit['deposit_balance'] + $debit['profit_balance'] + $debit['referral_balance'] + $debit['leadership_balance'];
        $updateWallet = $pdo->prepare('UPDATE wallets SET deposit_balance = ?, profit_balance = ?, referral_balance = ?, leadership_balance = ?, total_balance = ? WHERE id = ?');
        $updateWallet->execute([
            $debit['deposit_balance'],
            $debit['profit_balance'],
            $debit['referral_balance'],
            $debit['leadership_balance'],
            $newTotal,
            (int)$wallet['id']
        ]);
    }

    $planStmt = $pdo->prepare('SELECT id, daily_profit_percent, duration_days FROM investment_plans WHERE status = ? ORDER BY id ASC LIMIT 1');
    $planStmt->execute(['active']);
    $plan = $planStmt->fetch();

    if (!$plan) {
        $pdo->rollBack();
        sendJsonResponse(false, 'No active investment plan found.');
    }

    $planId = (int)$plan['id'];
    $dailyProfitPercent = (float)$plan['daily_profit_percent'];
    $durationDays = (int)$plan['duration_days'];
    $dailyProfit = round($amount * ($dailyProfitPercent / 100), 2);
    $totalProfit = round($dailyProfit * $durationDays, 2);
    $startDate = date('Y-m-d');
    $endDate = date('Y-m-d', strtotime("+$durationDays days"));
    $createdAt = date('Y-m-d H:i:s');
    $nextPayoutAt = (new DateTimeImmutable($createdAt, new DateTimeZone('Asia/Manila')))
        ->modify('+1 day')
        ->setTime((int)date('H', strtotime($createdAt)), (int)date('i', strtotime($createdAt)), (int)date('s', strtotime($createdAt)))
        ->format('Y-m-d H:i:s');

    $existingInvestmentStmt = $pdo->prepare('SELECT id FROM investments WHERE user_id = ? AND amount = ? AND start_date = ? AND status = ? LIMIT 1');
    $existingInvestmentStmt->execute([$userId, $amount, $startDate, 'running']);
    $existingInvestment = $existingInvestmentStmt->fetch();

    if (!$existingInvestment) {
        $insertInvestment = $pdo->prepare('INSERT INTO investments (user_id, plan_id, transaction_id, amount, daily_profit, total_profit, start_date, end_date, status, created_at, next_payout_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $insertInvestment->execute([$userId, $planId, null, $amount, $dailyProfit, $totalProfit, $startDate, $endDate, 'running', $createdAt, $nextPayoutAt]);
    }

    $pdo->prepare('UPDATE users SET status = ? WHERE id = ?')->execute(['active', $userId]);

    $pdo->commit();
    sendJsonResponse(true, 'Trade activated successfully.', [
        'used_available_balance' => $useAvailableBalance,
        'amount' => round($amount, 2)
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Trade activation failed: ' . $e->getMessage());
    sendJsonResponse(false, 'Unable to activate trade.');
}
?>