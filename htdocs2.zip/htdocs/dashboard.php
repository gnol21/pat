<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;

if ($userId <= 0) {
    sendJsonResponse(false, 'User not found.');
}

try {
    $userStmt = $pdo->prepare(
        'SELECT id, full_name, phone, balance, referral_code, status FROM users WHERE id = ? LIMIT 1'
    );
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch();

    if (!$user) {
        sendJsonResponse(false, 'User not found.');
    }

    $walletStmt = $pdo->prepare(
        'SELECT deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1'
    );
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();

    $sponsorStmt = $pdo->prepare(
        'SELECT u.full_name, u.referral_code FROM users u INNER JOIN users me ON me.sponsor_id = u.id WHERE me.id = ? LIMIT 1'
    );
    $sponsorStmt->execute([$userId]);
    $sponsor = $sponsorStmt->fetch();

    $settingsStmt = $pdo->prepare(
        'SELECT daily_profit_percent, investment_duration FROM settings ORDER BY id DESC LIMIT 1'
    );
    $settingsStmt->execute();
    $settings = $settingsStmt->fetch();

    $planStmt = $pdo->prepare(
        "SELECT plan_name, minimum_amount, daily_profit_percent, duration_days FROM investment_plans WHERE status = 'active' ORDER BY id ASC LIMIT 1"
    );
    $planStmt->execute();
    $plan = $planStmt->fetch();

    $investmentsStmt = $pdo->prepare(
        "SELECT i.id, i.amount, i.daily_profit, i.total_profit, i.status, i.start_date, i.end_date, i.created_at, p.plan_name, p.daily_profit_percent, p.duration_days
         FROM investments i
         LEFT JOIN investment_plans p ON p.id = i.plan_id
         WHERE i.user_id = ?
         ORDER BY i.created_at DESC"
    );
    $investmentsStmt->execute([$userId]);
    $investments = $investmentsStmt->fetchAll();

    $today = new DateTimeImmutable('today');
    $activeInvestments = [];
    foreach ($investments as $investment) {
        $status = strtolower((string)($investment['status'] ?? 'running'));
        $endDate = $investment['end_date'] ?? null;
        $isExpired = false;
        if ($endDate) {
            $endDateObj = new DateTimeImmutable((string)$endDate);
            $isExpired = $endDateObj < $today;
        }

        if ($status !== 'running' || $isExpired) {
            continue;
        }

        $startDate = $investment['start_date'] ?? null;
        $durationDays = max(1, (int)($investment['duration_days'] ?? 25));
        $cyclesCompleted = 1;
        if ($startDate) {
            $startDateObj = new DateTimeImmutable((string)$startDate);
            $daysElapsed = (int)$today->diff($startDateObj)->format('%r%a');
            $cyclesCompleted = max(1, min($durationDays, $daysElapsed + 1));
        }

        $remainingDays = max(0, $durationDays - $cyclesCompleted);
        $progressPercent = min(100, (int)round(($cyclesCompleted / $durationDays) * 100));

        $activeInvestments[] = array_merge($investment, [
            'status_label' => 'Active',
            'progress_percent' => $progressPercent,
            'cycles_completed' => $cyclesCompleted,
            'cycles_total' => $durationDays,
            'remaining_days' => $remainingDays,
        ]);
    }

    $investments = $activeInvestments;
    $hasTrade = count($investments) > 0;
    if ($user['status'] !== 'active' && $hasTrade) {
        $updateUserStatus = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $updateUserStatus->execute(['active', $userId]);
        $user['status'] = 'active';
    } elseif ($user['status'] === 'active' && !$hasTrade) {
        $updateUserStatus = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $updateUserStatus->execute(['inactive', $userId]);
        $user['status'] = 'inactive';
    }

    $availableBalance = 0.00;
    if ($wallet) {
        $availableBalance = (float)($wallet['deposit_balance'] ?? 0) + (float)($wallet['profit_balance'] ?? 0) + (float)($wallet['referral_balance'] ?? 0) + (float)($wallet['leadership_balance'] ?? 0);
    }

    if ($availableBalance <= 0) {
        $availableBalance = (float)($user['balance'] ?? 0);
    }

    $investmentsTotalStmt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total_invested FROM investments WHERE user_id = ?');
    $investmentsTotalStmt->execute([$userId]);
    $investmentsTotalRow = $investmentsTotalStmt->fetch();
    $investedBalance = $investmentsTotalRow ? (float)$investmentsTotalRow['total_invested'] : 0.0;

    $portfolioAmount = $availableBalance + $investedBalance;

    $dailyYield = $settings ? (float)$settings['daily_profit_percent'] : 0.0;
    $daysCycle = $settings ? (int)$settings['investment_duration'] : 25;

    $profitAmount = $wallet ? (float)$wallet['profit_balance'] : 0.0;
    $depositAmount = $wallet ? (float)$wallet['deposit_balance'] : 0.0;
    $bonusAmount = $wallet ? ((float)$wallet['referral_balance'] + (float)$wallet['leadership_balance']) : 0.0;

    $projectedGain = 0.0;
    if ($depositAmount > 0 && $dailyYield > 0) {
        $projectedGain = $depositAmount * ($dailyYield / 100);
    }

    $netGain = $profitAmount + $bonusAmount;
    $displayGain = $netGain > 0 ? $netGain : $projectedGain;

    sendJsonResponse(true, 'Dashboard loaded.', [
        'user' => [
            'id' => (int)$user['id'],
            'full_name' => $user['full_name'],
            'phone' => $user['phone'],
            'balance' => (float)$user['balance'],
            'referral_code' => $user['referral_code'],
            'status' => $user['status'],
            'is_active' => strtolower((string)$user['status']) === 'active',
            'sponsor_name' => $sponsor ? $sponsor['full_name'] : 'Admin',
            'sponsor_code' => $sponsor ? $sponsor['referral_code'] : 'ADMIN',
        ],
        'wallet' => [
            'available_balance' => $availableBalance,
            'invested_balance' => $investedBalance,
            'deposit_balance' => $wallet ? (float)$wallet['deposit_balance'] : 0.0,
            'profit_balance' => $wallet ? (float)$wallet['profit_balance'] : 0.0,
            'referral_balance' => $wallet ? (float)$wallet['referral_balance'] : 0.0,
            'leadership_balance' => $wallet ? (float)$wallet['leadership_balance'] : 0.0,
            'total_balance' => $portfolioAmount,
        ],
        'stats' => [
            'portfolio_amount' => $portfolioAmount,
            'ai_accuracy' => 96,
            'daily_yield' => $dailyYield,
            'days_cycle' => $daysCycle,
            'ai_confidence' => 96,
            'plan_name' => $plan ? $plan['plan_name'] : 'Prime Autonomous Trading',
            'plan_amount' => $plan ? (float)$plan['minimum_amount'] : 500.0,
            'computed_gain' => round($displayGain, 2),
            'computed_profit' => round($profitAmount, 2),
            'computed_bonus' => round($bonusAmount, 2),
            'has_trade' => $hasTrade,
            'is_active' => strtolower((string)$user['status']) === 'active',
            'investments' => array_map(function ($investment) {
                return [
                    'id' => (int)$investment['id'],
                    'plan_name' => $investment['plan_name'] ?? 'Prime Autonomous Trading',
                    'amount' => (float)$investment['amount'],
                    'daily_profit' => (float)$investment['daily_profit'],
                    'total_profit' => (float)$investment['total_profit'],
                    'status' => $investment['status'] ?? 'running',
                    'start_date' => $investment['start_date'],
                    'end_date' => $investment['end_date'],
                    'created_at' => $investment['created_at'] ?? null,
                    'daily_percent' => $investment['daily_profit_percent'] ?? 0,
                    'duration_days' => $investment['duration_days'] ?? 25,
                ];
            }, $investments),
        ],
    ]);
} catch (PDOException $e) {
    sendJsonResponse(false, 'Unable to load dashboard data.');
}
?>
