<?php
header('Content-Type: application/json');
require_once 'server.php';

$payload = file_get_contents('php://input');
if ($payload === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Empty payload']);
    exit;
}

// Verify webhook signature if a webhook secret is configured
$webhookSecret = getPaymongoWebhookSecret();
$signatureHeader = null;
$headers = [];
if (function_exists('getallheaders')) {
    $headers = getallheaders();
} else {
    foreach ($_SERVER as $k => $v) {
        if (strpos($k, 'HTTP_') === 0) {
            $name = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($k, 5)))));
            $headers[$name] = $v;
        }
    }
}

foreach ($headers as $hk => $hv) {
    if (strtolower($hk) === 'paymongo-signature') {
        $signatureHeader = $hv;
        break;
    }
}

$webhookSecretLoaded = $webhookSecret !== '';
if ($webhookSecretLoaded) {
    if (empty($signatureHeader)) {
        error_log('PayMongo webhook error: Missing webhook signature header');
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Missing signature header']);
        exit;
    }
} else {
    error_log('PayMongo webhook error: Webhook secret not configured');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Webhook secret not configured']);
    exit;
}

$timestamp = '';
$signatureTest = '';
$signatureLive = '';
$parts = array_filter(array_map('trim', explode(',', $signatureHeader)));
foreach ($parts as $part) {
    if (strpos($part, '=') === false) {
        continue;
    }
    [$key, $value] = explode('=', $part, 2);
    $key = strtolower(trim($key));
    $value = trim($value);

    if ($key === 't') {
        $timestamp = $value;
    } elseif ($key === 'te') {
        $signatureTest = $value;
    } elseif ($key === 'li') {
        $signatureLive = $value;
    }
}

if ($timestamp === '') {
    error_log('PayMongo webhook error: Missing webhook timestamp');
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid signature header']);
    exit;
}

$data = json_decode($payload, true);
$lived = false;
if (is_array($data)) {
    $livemodeValue = $data['data']['attributes']['livemode'] ?? $data['attributes']['livemode'] ?? null;
    if ($livemodeValue === true || $livemodeValue === 'true' || $livemodeValue === 1 || $livemodeValue === '1') {
        $lived = true;
    }
}

$signatureValue = '';
if ($lived) {
    $signatureValue = $signatureLive;
} else {
    $signatureValue = $signatureTest;
}

if ($signatureValue === '') {
    // Fallback to any available signature if mode detection failed
    $signatureValue = $signatureLive ?: $signatureTest;
}

$computedPayload = $timestamp . '.' . $payload;
$computedHex = hash_hmac('sha256', $computedPayload, $webhookSecret);

$providedSig = trim(preg_replace('/^sha256=/i', '', $signatureValue));
if (!hash_equals(strtolower($computedHex), strtolower($providedSig))) {
    error_log('PayMongo webhook error: Invalid webhook signature');
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid signature']);
    exit;
}

// Optional replay protection: reject webhooks older than 5 minutes
if (is_numeric($timestamp)) {
    $requestTime = (int)$timestamp;
    $now = time();
    if (abs($now - $requestTime) > 300) {
        error_log('PayMongo webhook error: Webhook timestamp outside allowed range');
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Webhook timestamp invalid']);
        exit;
    }
}

$data = json_decode($payload, true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid payload']);
    exit;
}

$eventType = '';
$eventResource = [];
$resourceType = '';
$resourceId = '';
$attributes = [];

if (isset($data['attributes']['data']) && is_array($data['attributes']['data'])) {
    $eventType = $data['attributes']['type'] ?? $data['type'] ?? '';
    $eventResource = $data['attributes']['data'];
} elseif (isset($data['data']) && is_array($data['data'])) {
    $inner = $data['data'];

    if (isset($inner['attributes']['data']) && is_array($inner['attributes']['data'])) {
        $eventType = $inner['attributes']['type'] ?? $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['attributes']['data'];
    } elseif (isset($inner['attributes']) && is_array($inner['attributes'])) {
        $eventType = $inner['attributes']['type'] ?? $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['attributes']['data'] ?? $inner;
    } elseif (isset($inner['data']) && is_array($inner['data'])) {
        $eventType = $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner['data'];
    } else {
        $eventType = $inner['type'] ?? $data['type'] ?? '';
        $eventResource = $inner;
    }
} else {
    $eventType = $data['type'] ?? '';
    $eventResource = $data['data'] ?? $data;
}

if (is_array($eventResource) && isset($eventResource['data']) && is_array($eventResource['data']) && !isset($eventResource['id']) && !isset($eventResource['type'])) {
    $eventResource = $eventResource['data'];
}

$resourceType = $eventResource['type'] ?? $eventType;
$resourceId = $eventResource['id'] ?? $eventResource['payment_intent_id'] ?? '';
$attributes = $eventResource['attributes'] ?? $eventResource;
$resourceStatus = isset($attributes['status']) ? strtolower((string)$attributes['status']) : '';

$metadata = [];
foreach([
    $eventResource['metadata'] ?? [],
    $attributes['metadata'] ?? [],
    $attributes['payment_intent']['metadata'] ?? [],
    $attributes['payment']['metadata'] ?? [],
] as $metadataSource) {
    if (is_array($metadataSource)) {
        $metadata = array_merge($metadata, $metadataSource);
    }
}

$transactionId = '';
if (!empty($attributes['payment_intent_id'])) {
    $transactionId = $attributes['payment_intent_id'];
} elseif (!empty($attributes['payment_intent']['id'])) {
    $transactionId = $attributes['payment_intent']['id'];
} elseif (!empty($attributes['payment']['id'])) {
    $transactionId = $attributes['payment']['id'];
} elseif (!empty($resourceId)) {
    $transactionId = $resourceId;
} elseif (!empty($attributes['id'])) {
    $transactionId = $attributes['id'];
}

$userId = isset($metadata['user_id']) ? (int)$metadata['user_id'] : 0;
$source = strtolower((string)($metadata['source'] ?? ''));

$amount = null;
if (isset($attributes['amount'])) {
    $amount = (float)$attributes['amount'] / 100;
} elseif (isset($attributes['amount_total'])) {
    $amount = (float)$attributes['amount_total'] / 100;
} elseif (isset($attributes['payment_intent']['amount'])) {
    $amount = (float)$attributes['payment_intent']['amount'] / 100;
} elseif (isset($attributes['payment']['amount'])) {
    $amount = (float)$attributes['payment']['amount'] / 100;
}


$acceptedEventTypes = [
    'checkout.session.completed',
    'checkout.session.payment.paid',
    'checkout_session.completed',
    'checkout_session.payment.paid',
    'checkout_session',
    'checkout.session',
    // Accept PayMongo payment events as well
    'payment.paid',
    'payment.completed',
    'payment',
];

$accepted = in_array($eventType, $acceptedEventTypes, true)
    || str_starts_with($eventType, 'checkout.session.')
    || str_starts_with($eventType, 'checkout_session.')
    || str_starts_with($eventType, 'payment.')
    || str_starts_with($eventType, 'payment_');

if (!$accepted) {
    echo json_encode(['success' => true, 'message' => 'Webhook received, event ignored']);
    exit;
}

if ($transactionId === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing payment identifier']);
    exit;
}

if ($userId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing user_id in PayMongo metadata']);
    exit;
}

if ($amount === null || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing amount in PayMongo payload']);
    exit;
}
file_put_contents(
    "payload_debug.log",
    print_r([
        "event" => $eventType,
        "transaction" => $transactionId,
        "user_id" => $userId,
        "amount" => $amount
    ], true),
    FILE_APPEND
);
try {
    $pdo = getDatabaseConnection();
    $pdo->beginTransaction();

    $depositStmt = $pdo->prepare('SELECT id, status FROM deposits WHERE transaction_id = ? LIMIT 1');
    $depositStmt->execute([$transactionId]);
    $existingDeposit = $depositStmt->fetch();

    if ($existingDeposit && strtolower($existingDeposit['status']) === 'approved') {
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Webhook already processed', 'transaction_id' => $transactionId]);
        exit;
    }

    if ($existingDeposit) {
        $depositId = (int)$existingDeposit['id'];
        $updateDeposit = $pdo->prepare(
            'UPDATE deposits SET amount = ?, payment_method = ?, status = ? WHERE id = ?'
        );
        $updateDeposit->execute([$amount, 'paymongo', 'approved', $depositId]);
    } else {
        $insertDeposit = $pdo->prepare(
            'INSERT INTO deposits (user_id, amount, payment_method, transaction_id, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())'
        );
        $insertDeposit->execute([$userId, $amount, 'paymongo', $transactionId, 'approved']);
        $depositId = (int)$pdo->lastInsertId();
    }

    $walletStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1');
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();
    $walletId = $wallet ? (int)$wallet['id'] : null;
 
    $isTradeActivation = ($source === 'pat_trade_now');
 
    if ($wallet) {
        if (!$isTradeActivation) {
            // Non-trade deposits increase the withdrawable deposit balance.
            $depositBal = (float)$wallet['deposit_balance'];
            $profitBal = (float)$wallet['profit_balance'];
            $referralBal = (float)$wallet['referral_balance'];
            $leadershipBal = (float)$wallet['leadership_balance'];
 
            $newDepositBalance = $depositBal + $amount;
            $newTotalBalance = $newDepositBalance + $profitBal + $referralBal + $leadershipBal;
 
            $walletUpdate = $pdo->prepare(
                'UPDATE wallets SET deposit_balance = ?, total_balance = ? WHERE id = ?'
            );
            $walletUpdate->execute([$newDepositBalance, $newTotalBalance, $walletId]);
        }
    } else {
        if ($isTradeActivation) {
            // Create wallet with zero deposit balance for trade activation; the amount becomes an investment instead.
            $depositBal = 0.0;
            $profitBal = 0.0;
            $referralBal = 0.0;
            $leadershipBal = 0.0;
            $totalBal = $depositBal + $profitBal + $referralBal + $leadershipBal;
 
            $walletInsert = $pdo->prepare(
                'INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, ?, 0, 0, 0, ?)'
            );
            $walletInsert->execute([$userId, $depositBal, $totalBal]);
        } else {
            // Create wallet with deposit amount and zero for other income types.
            $depositBal = $amount;
            $profitBal = 0.0;
            $referralBal = 0.0;
            $leadershipBal = 0.0;
            $totalBal = $depositBal + $profitBal + $referralBal + $leadershipBal;
 
            $walletInsert = $pdo->prepare(
                'INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, ?, 0, 0, 0, ?)'
            );
            $walletInsert->execute([$userId, $depositBal, $totalBal]);
        }
 
        $walletId = (int)$pdo->lastInsertId();
    }

    $investmentCreated = false;
    if ($source === 'pat_trade_now') {
        $planStmt = $pdo->prepare('SELECT id, daily_profit_percent, duration_days FROM investment_plans WHERE status = ? ORDER BY id ASC LIMIT 1');
        $planStmt->execute(['active']);
        $plan = $planStmt->fetch();

        if ($plan) {
            $planId = (int)$plan['id'];
            $dailyProfitPercent = (float)$plan['daily_profit_percent'];
            $durationDays = (int)$plan['duration_days'];

            $dailyProfit = round($amount * ($dailyProfitPercent / 100), 2);
            $totalProfit = round($dailyProfit * $durationDays, 2);
            $startDate = date('Y-m-d');
            $endDate = date('Y-m-d', strtotime("+$durationDays days"));

            if ($transactionId !== '') {
                $existingInvestmentStmt = $pdo->prepare(
                    'SELECT id FROM investments WHERE transaction_id = ? LIMIT 1'
                );
                $existingInvestmentStmt->execute([$transactionId]);
            } else {
                $existingInvestmentStmt = $pdo->prepare(
                    'SELECT id FROM investments WHERE user_id = ? AND amount = ? AND start_date = ? AND status = ? LIMIT 1'
                );
                $existingInvestmentStmt->execute([$userId, $amount, $startDate, 'running']);
            }
            $investmentExists = $existingInvestmentStmt->fetch();
 
            if (!$investmentExists) {
                $createdAt = date('Y-m-d H:i:s');
                $nextPayoutAt = (new DateTimeImmutable($createdAt, new DateTimeZone('Asia/Manila')))
                    ->modify('+1 day')
                    ->setTime((int)date('H', strtotime($createdAt)), (int)date('i', strtotime($createdAt)), (int)date('s', strtotime($createdAt)))
                    ->format('Y-m-d H:i:s');

                $investmentInsert = $pdo->prepare(
                    'INSERT INTO investments (user_id, plan_id, transaction_id, amount, daily_profit, total_profit, start_date, end_date, status, created_at, next_payout_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $investmentInsert->execute([
                    $userId,
                    $planId,
                    $transactionId !== '' ? $transactionId : null,
                    $amount,
                    $dailyProfit,
                    $totalProfit,
                    $startDate,
                    $endDate,
                    'running',
                    $createdAt,
                    $nextPayoutAt,
                ]);
                $investmentCreated = true;
                $investmentId = (int)$pdo->lastInsertId();

                // --- Referral payout: credit uplines (levels 1..5) immediately on investment activation ---
                try {
                    $settingsRefStmt = $pdo->prepare('SELECT referral_level1, referral_level2, referral_level3, referral_level4, referral_level5 FROM settings ORDER BY id DESC LIMIT 1');
                    $settingsRefStmt->execute();
                    $refSettings = $settingsRefStmt->fetch();

                    $currentUser = $userId;
                    $sponsorStmt = $pdo->prepare('SELECT sponsor_id FROM users WHERE id = ? LIMIT 1');

                    for ($lvl = 1; $lvl <= 5; $lvl++) {
                        $sponsorStmt->execute([$currentUser]);
                        $sRow = $sponsorStmt->fetch();
                        if (!$sRow || empty($sRow['sponsor_id'])) {
                            break;
                        }
                        $uplineId = (int)$sRow['sponsor_id'];

                        $percentCol = 'referral_level' . $lvl;
                        $percent = $refSettings && isset($refSettings[$percentCol]) ? (float)$refSettings[$percentCol] : 0.0;

                        if ($percent > 0) {
                            $bonusAmount = round($amount * ($percent / 100), 2);

                            if ($bonusAmount > 0) {
                                // Ensure upline has a wallet
                                $uWalletStmt = $pdo->prepare('SELECT id, referral_balance, total_balance FROM wallets WHERE user_id = ? LIMIT 1');
                                $uWalletStmt->execute([$uplineId]);
                                $uWallet = $uWalletStmt->fetch();
                                if ($uWallet) {
                                    $newReferral = (float)$uWallet['referral_balance'] + $bonusAmount;
                                    $newTotal = (float)$uWallet['total_balance'] + $bonusAmount;
                                    $uWalletUpdate = $pdo->prepare('UPDATE wallets SET referral_balance = ?, total_balance = ? WHERE id = ?');
                                    $uWalletUpdate->execute([$newReferral, $newTotal, $uWallet['id']]);
                                } else {
                                    // create wallet with referral credited
                                    $insertTotal = $bonusAmount;
                                    $walletInsert = $pdo->prepare('INSERT INTO wallets (user_id, deposit_balance, profit_balance, referral_balance, leadership_balance, total_balance) VALUES (?, ?, 0, ?, 0, ?)');
                                    $walletInsert->execute([$uplineId, 0.0, $bonusAmount, $insertTotal]);
                                }

                                // Insert referral_bonus record if table exists and not already present (idempotency guard)
                                try {
                                    $checkRb = $pdo->prepare('SELECT id FROM referral_bonus WHERE user_id = ? AND referred_user_id = ? AND investment_id = ? AND level = ? LIMIT 1');
                                    $checkRb->execute([$uplineId, $userId, $investmentId, $lvl]);
                                    $rbExists = $checkRb->fetch();
                                    if (!$rbExists) {
                                        $rbInsert = $pdo->prepare('INSERT INTO referral_bonus (user_id, referred_user_id, investment_id, level, percentage, bonus_amount, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())');
                                        $rbInsert->execute([$uplineId, $userId, $investmentId, $lvl, $percent, $bonusAmount]);
                                    }
                                } catch (PDOException $innerEx) {
                                    // table might not exist; ignore
                                }

                                // Insert transaction record if transactions table exists
                                try {
                                    $desc = sprintf('Referral bonus level %d from user %d investment %d', $lvl, $userId, $investmentId);
                                    $txInsert = $pdo->prepare('INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, ?, ?, ?, NOW())');
                                    $txInsert->execute([$uplineId, 'referral', $bonusAmount, $desc]);
                                } catch (PDOException $innerEx) {
                                    // ignore if table missing
                                }
                            }
                        }

                        // Move up the chain
                        $currentUser = $uplineId;
                    }
                } catch (PDOException $e) {
                    // be resilient: do not fail the whole webhook if referral payout cannot run
                    error_log('Referral payout error: ' . $e->getMessage());
                }
            }
  
            if ($walletId !== null) {
                $walletBalanceStmt = $pdo->prepare('SELECT id, deposit_balance, profit_balance, referral_balance, leadership_balance FROM wallets WHERE id = ? LIMIT 1');
                $walletBalanceStmt->execute([$walletId]);
                $walletBalance = $walletBalanceStmt->fetch();
 
                if ($walletBalance) {
                    $availableBalanceForPortfolio = (float)$walletBalance['deposit_balance'] + (float)$walletBalance['profit_balance'] + (float)$walletBalance['referral_balance'] + (float)$walletBalance['leadership_balance'];
                    $investmentsTotalStmt = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) AS total_invested FROM investments WHERE user_id = ?');
                    $investmentsTotalStmt->execute([$userId]);
                    $investmentsTotalRow = $investmentsTotalStmt->fetch();
                    $investedBalanceForPortfolio = $investmentsTotalRow ? (float)$investmentsTotalRow['total_invested'] : 0.0;
                    $portfolioTotal = $availableBalanceForPortfolio + $investedBalanceForPortfolio;
 
                    $walletUpdateTotal = $pdo->prepare('UPDATE wallets SET total_balance = ? WHERE id = ?');
                    $walletUpdateTotal->execute([$portfolioTotal, $walletBalance['id']]);
                }
            }
        }
        $statusUpdate = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
        $statusUpdate->execute(['active', $userId]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'PayMongo payment recorded',
        'transaction_id' => $transactionId,
        'deposit_id' => $depositId,
        'investment_created' => $investmentCreated,
    ]);
    exit;
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('PayMongo webhook error: Webhook persistence failed: ' . $e->getMessage());

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to persist webhook event']);
    exit;
}
?>