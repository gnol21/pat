<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();
$data = getJsonInput();

$userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
if ($userId <= 0) {
    sendJsonResponse(false, 'User not found.');
}

try {
    $walletStmt = $pdo->prepare(
        'SELECT referral_balance, leadership_balance FROM wallets WHERE user_id = ? LIMIT 1'
    );
    $walletStmt->execute([$userId]);
    $wallet = $walletStmt->fetch();

    $referralBalance = $wallet ? (float)$wallet['referral_balance'] : 0.0;
    $leadershipBalance = $wallet ? (float)$wallet['leadership_balance'] : 0.0;
    $teamEarnings = $referralBalance + $leadershipBalance;

    $settingsStmt = $pdo->prepare(
        'SELECT referral_level1, referral_level2, referral_level3, referral_level4, referral_level5 FROM settings ORDER BY id DESC LIMIT 1'
    );
    $settingsStmt->execute();
    $settings = $settingsStmt->fetch();

    $levels = [];

    // Compute referral counts per level (up to 5) and earnings per level when available
    $prevLevelIds = [$userId];
    for ($level = 1; $level <= 5; $level++) {
        // Find direct referrals from the previous level
        $ids = [];
        if (!empty($prevLevelIds)) {
            // Build IN clause placeholders
            $placeholders = rtrim(str_repeat('?,', count($prevLevelIds)), ',');
            $sql = "SELECT id FROM users WHERE sponsor_id IN ($placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($prevLevelIds);
            $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        }

        $count = is_array($ids) ? count($ids) : 0;

        // Compute earnings for this level if referral_bonus exists
        $earnings = 0.0;
        try {
            $earnStmt = $pdo->prepare('SELECT COALESCE(SUM(bonus_amount), 0) AS total_bonus FROM referral_bonus WHERE user_id = ? AND level = ?');
            $earnStmt->execute([$userId, $level]);
            $row = $earnStmt->fetch();
            if ($row && isset($row['total_bonus'])) {
                $earnings = (float)$row['total_bonus'];
            }
        } catch (PDOException $e) {
            // referral_bonus table might not exist in this schema — treat as zero
            $earnings = 0.0;
        }

        $column = 'referral_level' . $level;
        $value = $settings ? (float)$settings[$column] : 0.0;

        $levels[] = [
            'level' => $level,
            'value' => $value,
            'count' => $count,
            'earnings' => round($earnings, 2),
        ];

        // Prepare for next iteration
        $prevLevelIds = $ids ?: [];
    }

    // If caller requested a paginated list of members for a specific level, return that
    if (isset($data['list_level'])) {
        $listLevel = max(1, (int)$data['list_level']);
        $page = max(1, (int)($data['page'] ?? 1));
        $perPage = max(1, min(200, (int)($data['per_page'] ?? 25)));

        // Recompute the IDs for the requested level
        $current = [$userId];
        for ($i = 1; $i <= $listLevel; $i++) {
            if (empty($current)) {
                $current = [];
                break;
            }
            $placeholders = rtrim(str_repeat('?,', count($current)), ',');
            $sql = "SELECT id FROM users WHERE sponsor_id IN ($placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($current);
            $current = $stmt->fetchAll(PDO::FETCH_COLUMN);
        }

        $levelIds = is_array($current) ? $current : [];
        $total = count($levelIds);

        $offset = ($page - 1) * $perPage;
        $slice = array_slice($levelIds, $offset, $perPage);

        $members = [];
        if (!empty($slice)) {
            $placeholders = rtrim(str_repeat('?,', count($slice)), ',');
            $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE id IN ($placeholders)");
            $stmt->execute($slice);
            $rows = $stmt->fetchAll();

            // Preserve order according to slice
            $map = [];
            foreach ($rows as $r) {
                $map[(int)$r['id']] = $r['full_name'];
            }
            foreach ($slice as $id) {
                $members[] = [
                    'id' => (int)$id,
                    'full_name' => $map[(int)$id] ?? 'Unknown'
                ];
            }
        }

        sendJsonResponse(true, 'Members loaded.', [
            'members' => $members,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'level' => $listLevel
        ]);
    }

    // If caller requested the referral payouts ledger, return paginated referral_bonus rows (or fallback to transactions)
    if (isset($data['ledger'])) {
        $page = max(1, (int)($data['page'] ?? 1));
        $perPage = max(1, min(200, (int)($data['per_page'] ?? 25)));
        $offset = ($page - 1) * $perPage;

        $items = [];
        $total = 0;

        try {
            // Primary source: referral_bonus table
            $countStmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM referral_bonus WHERE user_id = ?');
            $countStmt->execute([$userId]);
            $cRow = $countStmt->fetch();
            $total = $cRow ? (int)$cRow['cnt'] : 0;

            if ($total > 0) {
                $stmt = $pdo->prepare('SELECT rb.created_at, rb.bonus_amount, rb.level, rb.percentage, rb.referred_user_id, u.full_name AS referred_name, rb.investment_id FROM referral_bonus rb LEFT JOIN users u ON u.id = rb.referred_user_id WHERE rb.user_id = ? ORDER BY rb.created_at DESC LIMIT ?, ?');
                // PDO with emulation disabled may not accept LIMIT bound parameters as ?, so bind as integers
                $stmt->bindValue(1, $userId, PDO::PARAM_INT);
                $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
                $stmt->bindValue(3, (int)$perPage, PDO::PARAM_INT);
                $stmt->execute();
                $rows = $stmt->fetchAll();

                foreach ($rows as $r) {
                    $items[] = [
                        'created_at' => $r['created_at'],
                        'referred_user_id' => (int)$r['referred_user_id'],
                        'referred_name' => $r['referred_name'] ?? 'Unknown',
                        'investment_id' => (int)$r['investment_id'],
                        'level' => (int)$r['level'],
                        'percentage' => (float)$r['percentage'],
                        'amount' => (float)$r['bonus_amount']
                    ];
                }
            }
        } catch (PDOException $e) {
            // fallback to transactions table if referral_bonus not available
            try {
                $countStmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM transactions WHERE user_id = ? AND type = 'referral'");
                $countStmt->execute([$userId]);
                $cRow = $countStmt->fetch();
                $total = $cRow ? (int)$cRow['cnt'] : 0;

                if ($total > 0) {
                    $stmt = $pdo->prepare("SELECT id, created_at, amount, description FROM transactions WHERE user_id = ? AND type = 'referral' ORDER BY created_at DESC LIMIT ?, ?");
                    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
                    $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
                    $stmt->bindValue(3, (int)$perPage, PDO::PARAM_INT);
                    $stmt->execute();
                    $rows = $stmt->fetchAll();

                    foreach ($rows as $r) {
                        $items[] = [
                            'created_at' => $r['created_at'],
                            'referred_user_id' => null,
                            'referred_name' => null,
                            'investment_id' => null,
                            'level' => null,
                            'percentage' => null,
                            'amount' => (float)$r['amount'],
                            'description' => $r['description'] ?? null
                        ];
                    }
                }
            } catch (PDOException $e2) {
                // give up and return empty
                $items = [];
                $total = 0;
            }
        }

        sendJsonResponse(true, 'Ledger loaded.', [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage
        ]);
    }

    $leadershipRank = 'Bronze';
    if ($leadershipBalance >= 10000) {
        $leadershipRank = 'Diamond';
    } elseif ($leadershipBalance >= 5000) {
        $leadershipRank = 'Gold';
    } elseif ($leadershipBalance >= 2500) {
        $leadershipRank = 'Silver';
    } elseif ($leadershipBalance > 0) {
        $leadershipRank = 'Bronze';
    }

    // Totals
    $totalReferrals = 0;
    $totalReferralEarnings = 0.0;
    foreach ($levels as $lvl) {
        $totalReferrals += (int)($lvl['count'] ?? 0);
        $totalReferralEarnings += (float)($lvl['earnings'] ?? 0.0);
    }

    sendJsonResponse(true, 'Team data loaded.', [
        'team_earnings' => round($teamEarnings, 2),
        'leadership_bonus' => round($leadershipBalance, 2),
        'leadership_rank' => $leadershipRank,
        'levels' => $levels,
        'totals' => [
            'referrals' => $totalReferrals,
            'referral_earnings' => round($totalReferralEarnings, 2)
        ]
    ]);
} catch (PDOException $e) {
    sendJsonResponse(false, 'Unable to load team data.');
}
?>
