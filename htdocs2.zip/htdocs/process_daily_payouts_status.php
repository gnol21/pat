<?php
header('Content-Type: application/json');
require_once 'server.php';

$pdo = getDatabaseConnection();

try {
    // Ensure the table exists (safe to call)
    $pdo->exec("CREATE TABLE IF NOT EXISTS process_status (
        name VARCHAR(100) PRIMARY KEY,
        last_run DATETIME NULL,
        last_success TINYINT(1) DEFAULT 0,
        last_message TEXT NULL,
        last_duration_seconds INT NULL,
        last_count INT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $stmt = $pdo->prepare('SELECT last_run, last_success, last_message, last_duration_seconds, last_count, updated_at FROM process_status WHERE name = ? LIMIT 1');
    $stmt->execute(['process_daily_payouts']);
    $row = $stmt->fetch();

    $now = new DateTimeImmutable('now', new DateTimeZone('Asia/Manila'));
    $nowSql = $now->format('Y-m-d H:i:s');

    // Count pending payouts
    $countStmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM investments WHERE status = 'running' AND next_payout_at IS NOT NULL AND next_payout_at <= ?");
    $countStmt->execute([$nowSql]);
    $countRow = $countStmt->fetch();
    $pending = $countRow ? (int)$countRow['cnt'] : 0;

    echo json_encode([
        'success' => true,
        'process' => 'process_daily_payouts',
        'last_run' => $row ? $row['last_run'] : null,
        'last_success' => $row ? (bool)$row['last_success'] : null,
        'last_message' => $row ? $row['last_message'] : null,
        'last_duration_seconds' => $row ? (int)$row['last_duration_seconds'] : null,
        'last_count' => $row ? (int)$row['last_count'] : null,
        'pending_payouts' => $pending,
        'now' => $nowSql
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to fetch status', 'error' => $e->getMessage()]);
}
?>