CREATE DATABASE prime_autonomous_trading;
USE prime_autonomous_trading;


-- ==========================
-- USERS TABLE
-- ==========================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sponsor_id INT NULL,
    full_name VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(15,2) DEFAULT 0.00,
    referral_code VARCHAR(20) UNIQUE NOT NULL,
    status ENUM('active','inactive','blocked') DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,a

    FOREIGN KEY (sponsor_id) REFERENCES users(id)
);



-- ==========================
-- SYSTEM SETTINGS
-- ==========================
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    minimum_investment DECIMAL(15,2) DEFAULT 500.00,
    minimum_withdrawal DECIMAL(15,2) DEFAULT 200.00,
    daily_profit_percent DECIMAL(5,2) DEFAULT 6.00,
    investment_duration INT DEFAULT 25,

    referral_level1 DECIMAL(5,2) DEFAULT 5.00,
    referral_level2 DECIMAL(5,2) DEFAULT 3.00,
    referral_level3 DECIMAL(5,2) DEFAULT 2.00,
    referral_level4 DECIMAL(5,2) DEFAULT 1.00,
    referral_level5 DECIMAL(5,2) DEFAULT 1.00,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO settings VALUES
(
NULL,
500,
200,
6,
25,
5,
3,
2,
1,
1,
NOW()
);



-- ==========================
-- INVESTMENT PLAN
-- ==========================
CREATE TABLE investment_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_name VARCHAR(100) NOT NULL,
    minimum_amount DECIMAL(15,2) DEFAULT 500,
    daily_profit_percent DECIMAL(5,2) DEFAULT 6,
    duration_days INT DEFAULT 25,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO investment_plans
(plan_name, minimum_amount, daily_profit_percent, duration_days)
VALUES
(
'Prime Autonomous Trading',
500,
6,
25
);



-- ==========================
-- USER INVESTMENTS
-- ==========================
CREATE TABLE investments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_id INT NOT NULL,

    amount DECIMAL(15,2) NOT NULL,
    daily_profit DECIMAL(15,2) NOT NULL,
    total_profit DECIMAL(15,2) DEFAULT 0,

    start_date DATE NOT NULL,
    end_date DATE NOT NULL,

    status ENUM(
        'running',
        'completed',
        'cancelled'
    ) DEFAULT 'running',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id),

    FOREIGN KEY(plan_id)
    REFERENCES investment_plans(id)
);



-- ==========================
-- DAILY PROFIT
-- ==========================
CREATE TABLE daily_profits (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,
    investment_id INT NOT NULL,

    profit_amount DECIMAL(15,2),
    profit_date DATE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id),

    FOREIGN KEY(investment_id)
    REFERENCES investments(id)
);



-- ==========================
-- WALLET
-- ==========================
CREATE TABLE wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT UNIQUE,

    deposit_balance DECIMAL(15,2) DEFAULT 0,
    profit_balance DECIMAL(15,2) DEFAULT 0,
    referral_balance DECIMAL(15,2) DEFAULT 0,
    leadership_balance DECIMAL(15,2) DEFAULT 0,

    total_balance DECIMAL(15,2) DEFAULT 0,


    FOREIGN KEY(user_id)
    REFERENCES users(id)
);



-- ==========================
-- DEPOSITS
-- ==========================
CREATE TABLE deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    amount DECIMAL(15,2),
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),

    status ENUM(
        'pending',
        'approved',
        'rejected'
    ) DEFAULT 'pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id)
);



-- ==========================
-- WITHDRAWALS
-- ==========================
CREATE TABLE withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    amount DECIMAL(15,2),

    payment_method VARCHAR(50),
    wallet_address VARCHAR(255),

    process_type VARCHAR(50)
    DEFAULT 'instant',

    status ENUM(
        'pending',
        'approved',
        'completed',
        'rejected'
    )
    DEFAULT 'pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id)
);



-- ==========================
-- REFERRAL BONUS
-- ==========================
CREATE TABLE referral_bonus (

    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,
    referred_user_id INT NOT NULL,

    investment_id INT NOT NULL,

    level INT NOT NULL,

    percentage DECIMAL(5,2),

    bonus_amount DECIMAL(15,2),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_referral_bonus_unique (user_id, referred_user_id, investment_id, level),

    FOREIGN KEY(user_id)
    REFERENCES users(id),

    FOREIGN KEY(referred_user_id)
    REFERENCES users(id),

    FOREIGN KEY(investment_id)
    REFERENCES investments(id)

);



-- ==========================
-- LEADERSHIP BONUS
-- ==========================
CREATE TABLE leadership_bonus (

    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    title VARCHAR(100),

    bonus_amount DECIMAL(15,2),

    description TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id)

);



-- ==========================
-- TRANSACTIONS HISTORY
-- ==========================
CREATE TABLE transactions (

    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    type ENUM(
        'deposit',
        'withdrawal',
        'investment',
        'profit',
        'referral',
        'leadership'
    ),

    amount DECIMAL(15,2),

    description TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,


    FOREIGN KEY(user_id)
    REFERENCES users(id)

);