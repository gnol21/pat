<?php
header('Content-Type: application/json');
require_once 'server.php';

$data = getJsonInput();

$testMode = !empty($data['test_mode']) || (!empty($_GET['test_mode']) && $_GET['test_mode'] == '1');
$userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
if ($userId <= 0 && isset($data['user']) && is_array($data['user'])) {
    $userId = (int)($data['user']['id'] ?? 0);
}
if ($userId <= 0 && isset($_GET['user_id'])) {
    $userId = (int)$_GET['user_id'];
}

$amount = isset($data['amount']) ? (float)$data['amount'] : 0;
$currency = isset($data['currency']) ? (string)$data['currency'] : 'PHP';
$description = isset($data['description']) ? (string)$data['description'] : 'PAT Trade Activation';
$userFullName = '';
if (isset($data['user']['full_name'])) {
    $userFullName = trim((string)$data['user']['full_name']);
}
if ($description === 'PAT Trade Activation' && $userFullName !== '') {
    $description = 'PAT Trade Activation - ' . $userFullName;
}
$successUrl = isset($data['success_url']) ? (string)$data['success_url'] : '';
$cancelUrl = isset($data['cancel_url']) ? (string)$data['cancel_url'] : '';
$returnUrl = isset($data['return_url']) ? (string)$data['return_url'] : '';
$redirectUrl = isset($data['redirect_url']) ? (string)$data['redirect_url'] : '';
$paymentMethodTypes = isset($data['payment_method_types']) && is_array($data['payment_method_types'])
    ? array_values(array_filter(array_map('strval', $data['payment_method_types'])))
    : [];
if (empty($paymentMethodTypes)) {
    $paymentMethodTypes = ['qrph'];
}

if ($successUrl === '' && $returnUrl !== '') {
    $successUrl = $returnUrl;
}
if ($successUrl === '' && $redirectUrl !== '') {
    $successUrl = $redirectUrl;
}

if ($userId <= 0 && !$testMode) {
    sendJsonResponse(false, 'User not found.');
}

if ($amount < 500) {
    sendJsonResponse(false, 'Minimum trade amount is ₱500.');
}

$secretKey = getPaymongoSecretKey();
if ($secretKey === '') {
    sendJsonResponse(false, 'PayMongo secret key is not configured on the server. Set PAYMONGO_SECRET_KEY (or add a local .env file) with your live key before using checkout sessions.');
}

$amountInCents = (int)round($amount * 100);
$body = [
    'data' => [
        'attributes' => [
            'line_items' => [
                [
                    'name' => 'PAT Trade',
                    'amount' => $amountInCents,
                    'currency' => $currency,
                    'quantity' => 1,
                    'description' => $description,
                ],
            ],
            'payment_method_types' => $paymentMethodTypes,
            'metadata' => [
                'user_id' => (string)$userId,
                'source' => 'pat_trade_now',
            ],
        ],
    ],
];

if ($successUrl !== '') {
    $body['data']['attributes']['success_url'] = $successUrl;
}

if ($cancelUrl !== '') {
    $body['data']['attributes']['cancel_url'] = $cancelUrl;
}

$ch = curl_init('https://api.paymongo.com/v1/checkout_sessions');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Basic ' . base64_encode($secretKey . ':'),
    'Content-Type: application/json',
]);

$response = curl_exec($ch);
$curlErrNo = curl_errno($ch);
$curlError = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response === false || $curlErrNo !== 0) {
    sendJsonResponse(false, 'Unable to contact PayMongo: ' . ($curlError ?: 'curl error'));
}

$responseData = json_decode($response, true);
if (!is_array($responseData)) {
    sendJsonResponse(false, 'Invalid PayMongo response.');
}

if ($httpCode >= 400) {
    $errorMessage = 'PayMongo request failed.';
    if (!empty($responseData['errors']) && is_array($responseData['errors'])) {
        $details = [];
        foreach ($responseData['errors'] as $error) {
            $details[] = $error['detail'] ?? $error['message'] ?? '';
        }
        $errorMessage .= ' ' . trim(implode(' ', array_filter($details)));
    } elseif (!empty($responseData['message'])) {
        $errorMessage .= ' ' . $responseData['message'];
    }
    sendJsonResponse(false, trim($errorMessage));
}

$checkoutUrl = $responseData['data']['attributes']['checkout_url']
    ?? $responseData['data']['attributes']['url']
    ?? $responseData['data']['url']
    ?? '';
if ($checkoutUrl === '') {
    sendJsonResponse(false, 'PayMongo checkout session URL was not returned.');
}

sendJsonResponse(true, 'PayMongo checkout session created.', [
    'checkout_url' => $checkoutUrl,
    'url' => $checkoutUrl,
    'payment_id' => $responseData['data']['id'] ?? '',
    'session' => $responseData['data'] ?? [],
]);
?>
